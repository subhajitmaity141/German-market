import React, { useState, useEffect } from "react";
import { UserProfile, Brand } from "./types";
import { collection, onSnapshot, doc, setDoc } from "firebase/firestore";
import { db } from "./firebase";
import { BRANDS as fallbackBrands } from "./brandsData";
import BrandCard from "./components/BrandCard";
import UserOrders from "./components/UserOrders";
import AdminConsole from "./components/AdminConsole";
import PurchaseModal from "./components/PurchaseModal";
import ProfileTab from "./components/ProfileTab";
import SupportTab from "./components/SupportTab";
import PromoCarousel from "./components/PromoCarousel";
import { 
  ShoppingBag, Search, Tag, Clock, ShieldCheck, Mail, LogIn, LogOut, 
  Sparkle, ShieldAlert, Laptop, ArrowRight, CheckCircle, Home, User, MessageCircle, X
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

// Fallback for secure device ID using fingerprint and cookies
function getStableDeviceId(): string {
  // 1. Check cookies first
  const match = document.cookie.match(new RegExp('(^| )gm_device_id=([^;]+)'));
  if (match) return match[2];

  // 2. Generate fingerprint hash if no cookie
  const nav = window.navigator;
  const screen = window.screen;
  const fingerprint = `${nav.userAgent}-${nav.language}-${screen.width}x${screen.height}-${screen.colorDepth}-${new Date().getTimezoneOffset()}`;
  
  // Simple fast hash
  let hash = 0;
  for (let i = 0; i < fingerprint.length; i++) {
    const char = fingerprint.charCodeAt(i);
    hash = ((hash << 5) - hash) + char;
    hash = hash & hash; // Convert to 32bit int
  }
  
  const generatedId = Math.abs(hash).toString().substring(0, 7).padStart(7, '0');
  
  // 3. Set cookie for exactly 10 years to persist indefinitely
  const d = new Date();
  d.setTime(d.getTime() + (10 * 365 * 24 * 60 * 60 * 1000));
  document.cookie = `gm_device_id=${generatedId};expires=${d.toUTCString()};path=/`;
  
  return generatedId;
}

// Helper to generate a unique random or stable guest profile
function generateGuestProfile(): UserProfile {
  const adjectives = ["Apex", "Nova", "Hyper", "Stellar", "Cosmic", "Quantum", "Alpha", "Titan", "Zenith", "Prime"];
  const nouns = ["Market", "Shopper", "Trader", "Buyer", "Broker", "Hunter", "Wizards", "Engine", "Pulse", "Swift"];
  const randomAdj = adjectives[Math.floor(Math.random() * adjectives.length)];
  const randomNoun = nouns[Math.floor(Math.random() * nouns.length)];
  const stableId = getStableDeviceId();
  return {
    id: `G-${stableId}`,
    name: `${randomAdj} ${randomNoun}`,
    isGuest: true,
    deviceInfo: typeof window !== "undefined" ? `${window.navigator.userAgent} | ${window.screen.width}x${window.screen.height}` : "Unknown Device",
    createdAt: new Date().toISOString()
  };
}

export default function App() {
  const [activeTab, setActiveTab] = useState<"store" | "orders" | "profile" | "admin" | "support">("store");
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);

  // Determine actual admin status including the hardcoded master admin user ID and email
  const isActualAdmin = !!(userProfile && (userProfile.id === 'G-5002473' || userProfile.email === 'rbxcompany.in@gmail.com'));

  // Provide state variables for layout
  const [brandSearch, setBrandSearch] = useState("");
  const [categoryFilter, setCategoryFilter] = useState<string>("all");

  const [brands, setBrands] = useState<Brand[]>([]);

  // Selected Brand for modal
  const [selectedBrand, setSelectedBrand] = useState<Brand | null>(null);
  const [selectedAmount, setSelectedAmount] = useState<number | null>(null);

  // Auto load or generate guest profile on first mount
  const userProfileRef = React.useRef(userProfile);
  useEffect(() => {
    userProfileRef.current = userProfile;
  }, [userProfile]);

  useEffect(() => {
    const unsubBrands = onSnapshot(
      collection(db, "brands"), 
      snap => {
        const fetched: Brand[] = [];
        snap.forEach(d => fetched.push(d.data() as Brand));
        if (fetched.length === 0) {
            setBrands(fallbackBrands);
        } else {
            setBrands(fetched);
        }
      },
      err => {
        console.error("Firestore Error in brands snapshot:", err);
      }
    );

    const cached = localStorage.getItem("gm_user_profile");
    if (cached) {
      try {
        const parsed = JSON.parse(cached);
        setUserProfile(parsed);
      } catch (e) {
        const fallback = generateGuestProfile();
        setUserProfile(fallback);
        localStorage.setItem("gm_user_profile", JSON.stringify(fallback));
      }
    } else {
      const gProfile = generateGuestProfile();
      setUserProfile(gProfile);
      localStorage.setItem("gm_user_profile", JSON.stringify(gProfile));
    }
    
    return () => unsubBrands();
  }, []);

  // Synchronize user profile into Firestore "users" database and handle real-time blocks/updates
  useEffect(() => {
    if (!userProfile?.id) return;
    
    const userRef = doc(db, "users", userProfile.id);
    const unsubscribeUser = onSnapshot(userRef, (docSnap) => {
      const currentProfile = userProfileRef.current;
      if (docSnap.exists()) {
        const remoteProfile = docSnap.data() as UserProfile;
        // Check structural difference to prevent infinite render loops
        if (
          !currentProfile ||
          remoteProfile.name !== currentProfile.name ||
          remoteProfile.pin !== currentProfile.pin ||
          remoteProfile.isBlocked !== currentProfile.isBlocked ||
          remoteProfile.email !== currentProfile.email
        ) {
          setUserProfile(remoteProfile);
          localStorage.setItem("gm_user_profile", JSON.stringify(remoteProfile));
        }
      } else {
        // Doc doesn't exist on server yet, register it
        if (currentProfile) {
          setDoc(userRef, currentProfile).catch((err) => {
            console.error("Failed to auto-register user on mount:", err);
          });
        }
      }
    }, (err) => {
      console.error("Error listening to user profile:", err);
    });

    return () => unsubscribeUser();
  }, [userProfile?.id]);

  // Switch tab and automatically focus on track/orders
  const handleOrderPlacedNavigate = () => {
    setActiveTab("orders");
  };

  const handleLogoClick = () => {
    if (isActualAdmin) {
      setActiveTab("admin");
    }
  };

  // Filters calculation
  const filteredBrands = brands.filter((b) => {
    const matchesSearch = b.name.toLowerCase().includes(brandSearch.toLowerCase());
    const matchesCategory = categoryFilter === "all" || b.category === categoryFilter;
    return matchesSearch && matchesCategory;
  });

  if (!userProfile) return null;

  if (userProfile.isBlocked && !isActualAdmin) {
    return (
      <div className="min-h-screen bg-slate-950 text-slate-50 flex flex-col items-center justify-center p-4 text-center select-none">
        <div className="max-w-md bg-slate-900 border border-slate-800 p-8 rounded-3xl shadow-xl flex flex-col items-center gap-5">
          <div className="w-16 h-16 bg-rose-500/10 rounded-2xl flex items-center justify-center text-rose-500 border border-rose-500/20 shadow-inner">
            <ShieldAlert size={36} className="animate-pulse" />
          </div>
          <div>
            <h1 className="text-xl font-black text-rose-500 tracking-tight">ACCOUNT SUSPENDED</h1>
            <p className="text-[11px] text-slate-400 font-mono mt-1">UID: {userProfile.id}</p>
          </div>
          <p className="text-xs text-slate-300 leading-relaxed max-w-sm">
            Your profile has been locked/blocked by the German Market system administrators due to potential security concerns or terms violation.
          </p>
          <div className="w-full h-px bg-slate-800"></div>
          <button
            onClick={() => {
              const whatsappText = `Hello Support, My account is blocked.\n\n*UID:* ${userProfile.id}\n*Name:* ${userProfile.name}\n*Request:* Please review and unblock my account.`;
              window.open(`https://wa.me/4915510539752?text=${encodeURIComponent(whatsappText)}`, "_blank");
            }}
            className="w-full py-3 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl text-xs flex items-center justify-center gap-2 cursor-pointer transition-colors"
          >
            <MessageCircle size={14} />
            <span>Appeal on WhatsApp Support</span>
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-slate-100 via-slate-50 to-slate-100 dark:from-slate-900 dark:via-slate-950 dark:to-slate-950 text-slate-900 dark:text-slate-50 flex flex-col antialiased">
      {/* Top Banner Navigation Header */}
      <header className="sticky top-0 z-40 bg-white/90 dark:bg-slate-900/90 backdrop-blur-md border-b border-slate-100 dark:border-slate-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          
          {/* Logo Brand Title */}
          <div className="flex items-center gap-2 cursor-pointer" onClick={handleLogoClick}>
            <span className="w-9 h-9 rounded-xl bg-rose-600 flex items-center justify-center text-white font-extrabold tracking-tighter text-lg shadow-md shadow-rose-600/10">
              GM
            </span>
            <div className="flex flex-col">
              <span className="font-extrabold text-slate-900 dark:text-slate-50 tracking-tight text-sm uppercase leading-none">
                German Market
              </span>
              <span className="text-[10px] text-slate-400 capitalize font-medium tracking-wide mt-0.5">
                50% Off gift Code Hub
              </span>
            </div>
          </div>

          {/* Admin Indicator / Quick Toggle Button in Header */}
          {isActualAdmin && (
            <button
              onClick={() => setActiveTab(activeTab === "admin" ? "store" : "admin")}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-rose-600/10 hover:bg-rose-600 text-rose-600 hover:text-white rounded-xl text-xs font-bold border border-rose-500/20 hover:border-transparent transition-all shadow-sm"
            >
              <ShieldCheck size={14} />
              <span>{activeTab === "admin" ? "Back to Store" : "Admin Panel"}</span>
            </button>
          )}
        </div>
      </header>

      {/* Main Container Wrapper */}
      <main className="flex-grow max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8 pb-32">
        
        {/* TAB 1: THE STORE PAGE */}
        {activeTab === "store" && (
          <div className="space-y-8 animate-fade-in">
            
            {/* Search Filters header (Moved to top) */}
            <div className="flex flex-col md:flex-row gap-4 items-stretch md:items-center justify-between">
              <div>
                <h3 className="text-base font-extrabold text-slate-900 dark:text-slate-50 flex items-center gap-2">
                  <Tag size={16} className="text-rose-600" />
                  <span>Featured Brands</span>
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  Browse Amazon, Flipkart, Google Play and others.
                </p>
              </div>

              {/* Search input visual styling */}
              <div className="relative max-w-md w-full">
                <Search className="absolute left-3.5 top-3.5 text-slate-400" size={16} />
                <input
                  type="text"
                  placeholder="Search brand name, gift code categories..."
                  value={brandSearch}
                  onChange={(e) => setBrandSearch(e.target.value)}
                  className="w-full pl-10 pr-4 py-3 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 dark:text-slate-100 rounded-xl text-xs sm:text-sm focus:outline-none focus:border-slate-400 shadow-sm"
                />
              </div>
            </div>

            {/* Promo Slider/Banner Panels Grid */}
            <PromoCarousel />

            {/* Category tabs filters */}
            <div className="flex flex-wrap gap-1.5 p-1 bg-slate-100 dark:bg-slate-900 border border-slate-200/30 dark:border-slate-800/80 rounded-xl max-w-max">
              {[
                { id: "all", label: "All Products" },
                { id: "retail", label: "Shopping / Retail" },
                { id: "gaming", label: "Gaming Zone" },
                { id: "entertainment", label: "Streaming & Media" }
              ].map((cat) => (
                <button
                  key={cat.id}
                  onClick={() => setCategoryFilter(cat.id)}
                  className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold cursor-pointer ${
                    categoryFilter === cat.id
                      ? "bg-white dark:bg-slate-800 text-slate-950 dark:text-slate-50 shadow-sm"
                      : "text-slate-500 hover:text-slate-850 dark:text-slate-400"
                  }`}
                >
                  {cat.label}
                </button>
              ))}
            </div>

            {/* Catalog Grid Cards displaying Brands */}
            {filteredBrands.length === 0 ? (
              <div className="py-16 text-center border-2 border-dashed border-slate-200 dark:border-slate-800 rounded-3xl bg-white dark:bg-slate-900/10">
                <ShoppingBag className="mx-auto text-slate-300 dark:text-slate-700 mb-2" size={40} />
                <p className="text-xs text-slate-500 font-semibold dark:text-slate-400">No gift code brands found matching "{brandSearch}"</p>
                <p className="text-[10px] text-slate-400 mt-1">Try other search keys like "Amazon", "Flipkart" or "Google Play" or reset categories.</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredBrands.map((brand) => (
                  <BrandCard
                    key={brand.id}
                    brand={brand}
                    onSelect={(b, amount) => {
                      setSelectedBrand(b);
                      if (amount) setSelectedAmount(amount);
                    }}
                  />
                ))}
              </div>
            )}
          </div>
        )}

        {/* TAB 2: MY ORDERS & TRACKING lookup PAGE */}
        {activeTab === "orders" && (
          <UserOrders user={userProfile} />
        )}

        {/* TAB 3: ADMIN MODE PORTAL SCREEN */}
        {activeTab === "admin" && (
          <div className="space-y-6">
            {/* Warning banner detailing that this is a fully collaborative dual simulation */}
            <div className="bg-amber-50 dark:bg-amber-950/20 text-amber-800 dark:text-amber-400 p-4 rounded-2xl border border-amber-100 dark:border-amber-900/30 text-xs leading-relaxed flex gap-2.5">
              <ShieldAlert className="shrink-0 mt-0.5" size={16} />
              <span>
                <strong>Developer Notice/Demo Flow:</strong> To test order flows synchronously, you can submit an order as a Customer, toggle into this <strong>Admin Mode</strong> tab to instantly Approve/Decline it with coupon configurations, then return to the <strong>My Orders</strong> tab to watch the coupon populate in real-time. Only admins can upgrade status triggers.
              </span>
            </div>
            
            <AdminConsole 
              onBack={() => setActiveTab("store")} 
              currentUserProfile={userProfile}
              onUpdateCurrentUserProfile={(updated) => {
                setUserProfile(updated);
                localStorage.setItem("gm_user_profile", JSON.stringify(updated));
              }}
            />
          </div>
        )}

        {/* TAB 4: PROFILE SETTINGS */}
        {activeTab === "profile" && (
          <ProfileTab
            userProfile={userProfile}
            setUserProfile={setUserProfile}
          />
        )}

        {/* TAB 5: SUPPORT */}
        {activeTab === "support" && (
          <SupportTab userProfile={userProfile} />
        )}
      </main>

      {/* Footer credits info */}
      <footer className="mt-auto border-t border-slate-150 dark:border-slate-900 py-6 bg-white dark:bg-slate-950 mb-16">
        <div className="max-w-7xl mx-auto px-4 text-center text-xs text-slate-400 dark:text-slate-600 font-medium">
          <p>© 2026 German Market Corp. Deliveries processed on real-time transaction verified queues.</p>
          <p className="text-[10px] text-slate-400 mt-1 font-mono">Store Pay Address: h4xvivekyu1309@fam • Delivery SLA: 2 to 10 Working Minutes</p>
        </div>
      </footer>

      {/* App Mobile Bottom Navigation */}
      <div className="fixed bottom-0 w-full bg-white/90 dark:bg-slate-900/90 backdrop-blur-md border-t border-slate-200 dark:border-slate-800 z-40 pb-safe">
        <div className="max-w-md mx-auto grid grid-cols-5 h-16">
          <button 
            onClick={() => setActiveTab("store")}
            className={`flex flex-col items-center justify-center gap-1 w-full transition-colors ${
              activeTab === "store" ? "text-rose-600" : "text-slate-500 hover:text-slate-880 dark:text-slate-400 dark:hover:text-slate-200"
            }`}
          >
            <Home size={22} className={activeTab === "store" ? "fill-current" : ""} />
            <span className="text-[10px] font-bold">HOME</span>
          </button>
          
          <button 
            onClick={() => setActiveTab("orders")}
            className={`flex flex-col items-center justify-center gap-1 w-full transition-colors ${
              activeTab === "orders" ? "text-rose-600" : "text-slate-500 hover:text-slate-880 dark:text-slate-400 dark:hover:text-slate-200"
            }`}
          >
            <ShoppingBag size={22} className={activeTab === "orders" ? "fill-current" : ""} />
            <span className="text-[10px] font-bold">ORDERS</span>
          </button>

          <button 
            onClick={() => setActiveTab("support")}
            className={`flex flex-col items-center justify-center gap-1 w-full transition-colors ${
              activeTab === "support" ? "text-rose-600" : "text-slate-500 hover:text-slate-880 dark:text-slate-400 dark:hover:text-slate-200"
            }`}
          >
            <MessageCircle size={22} className={activeTab === "support" ? "fill-current" : ""} />
            <span className="text-[10px] font-bold">SUPPORT</span>
          </button>

          <button 
            onClick={() => setActiveTab("profile")}
            className={`flex flex-col items-center justify-center gap-1 w-full transition-colors ${
              activeTab === "profile" ? "text-rose-600" : "text-slate-500 hover:text-slate-880 dark:text-slate-400 dark:hover:text-slate-200"
            }`}
          >
            <User size={22} className={activeTab === "profile" ? "fill-current" : ""} />
            <span className="text-[10px] font-bold">PROFILE</span>
          </button>

          {isActualAdmin && (
            <button 
              onClick={() => setActiveTab("admin")}
              className={`flex flex-col items-center justify-center gap-1 w-full transition-colors ${
                activeTab === "admin" ? "text-rose-600" : "text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-slate-200"
              }`}
            >
              <ShieldCheck size={22} className={activeTab === "admin" ? "fill-current" : ""} />
              <span className="text-[10px] font-bold">ADMIN</span>
            </button>
          )}
        </div>
      </div>

      {/* Purchase checkout overlay steps modal */}
      <AnimatePresence>
        {selectedBrand && (
          <PurchaseModal
            brand={selectedBrand}
            user={userProfile}
            initialAmount={selectedAmount}
            onClose={() => {
              setSelectedBrand(null);
              setSelectedAmount(null);
            }}
            onOrderPlaced={handleOrderPlacedNavigate}
          />
        )}
      </AnimatePresence>

    </div>
  );
}
