import React, { useState, useEffect } from "react";
import { collection, onSnapshot, doc, setDoc, deleteDoc } from "firebase/firestore";
import { db, handleFirestoreError, OperationType } from "../firebase";
import { PromoBanner } from "../types";
import { Plus, Trash2, Image as ImageIcon, Sparkles, X, ChevronRight, AlertCircle } from "lucide-react";

export default function BannerManagement() {
  const [banners, setBanners] = useState<PromoBanner[]>([]);
  const [loading, setLoading] = useState(true);
  const [isAdding, setIsAdding] = useState(false);
  
  // New banner state
  const [title, setTitle] = useState("");
  const [subtitle, setSubtitle] = useState("");
  const [badge, setBadge] = useState("");
  const [imageUrl, setImageUrl] = useState("");
  const [link, setLink] = useState("");

  const [notification, setNotification] = useState<{ message: string; type: "success" | "error" } | null>(null);

  const showNotification = (message: string, type: "success" | "error" = "success") => {
    setNotification({ message, type });
    setTimeout(() => {
      setNotification(prev => prev?.message === message ? null : prev);
    }, 4000);
  };

  useEffect(() => {
    const bannersCol = collection(db, "banners");
    const unsubscribe = onSnapshot(bannersCol, (snapshot) => {
       const list: PromoBanner[] = [];
       snapshot.forEach((doc) => {
         list.push(doc.data() as PromoBanner);
       });
       // Sort by creation date
       list.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
       setBanners(list);
       setLoading(false);
    }, (err) => {
       console.error("Failed to load banners:", err);
       setLoading(false);
       handleFirestoreError(err, OperationType.LIST, "banners");
    });

    return () => unsubscribe();
  }, []);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 3 * 1024 * 1024) {
      showNotification("Image is too big! Maximum size is 3MB.", "error");
      return;
    }

    const reader = new FileReader();
    reader.onloadend = () => {
      if (typeof reader.result === "string") {
        setImageUrl(reader.result);
        showNotification("Banner image uploaded successfully");
      }
    };
    reader.readAsDataURL(file);
  };

  const handleSaveBanner = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !subtitle.trim()) {
      showNotification("Title and short description are required!", "error");
      return;
    }

    const newId = "banner_" + Math.random().toString(36).substring(2, 9);
    const newBanner: PromoBanner = {
      id: newId,
      title: title.trim(),
      subtitle: subtitle.trim(),
      badge: badge.trim() || undefined,
      imageUrl: imageUrl.trim() || "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=800&auto=format&fit=crop",
      link: link.trim() || undefined,
      createdAt: new Date().toISOString()
    };

    try {
      await setDoc(doc(db, "banners", newId), newBanner);
      showNotification("Promotional banner added successfully!");
      // Reset form
      setTitle("");
      setSubtitle("");
      setBadge("");
      setImageUrl("");
      setLink("");
      setIsAdding(false);
    } catch (err: any) {
      showNotification("Database save failed: " + err.message, "error");
      handleFirestoreError(err, OperationType.WRITE, `banners/${newId}`);
    }
  };

  const handleDeleteBanner = async (id: string) => {
    if (!confirm("Are you sure you want to delete this promotional banner?")) return;
    try {
      await deleteDoc(doc(db, "banners", id));
      showNotification("Banner removed successfully");
    } catch (err: any) {
      showNotification("Delete failed: " + err.message, "error");
      handleFirestoreError(err, OperationType.DELETE, `banners/${id}`);
    }
  };

  return (
    <div className="space-y-6 text-sans">
      {notification && (
        <div className={`fixed bottom-6 right-6 z-50 p-4 rounded-xl shadow-2xl flex items-center gap-2 border text-xs font-bold animate-slide-in ${
          notification.type === "error" 
            ? "bg-red-950 border-red-800 text-red-200" 
            : "bg-emerald-950 border-emerald-800 text-emerald-200"
        }`}>
          <Sparkles size={16} />
          <span>{notification.message}</span>
        </div>
      )}

      {/* Header action bar */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 bg-slate-900 border border-slate-800 p-5 rounded-2xl">
        <div>
          <h3 className="text-base font-extrabold text-white">Dynamic Banner Slider Management</h3>
          <p className="text-xs text-slate-400 mt-1">Add, update, or remove promotional slider banners shown on the client storefront home carousel.</p>
        </div>
        <button
          onClick={() => setIsAdding(!isAdding)}
          className="px-4 py-2 bg-rose-600 hover:bg-rose-500 text-white rounded-lg text-xs font-bold flex items-center gap-1.5 cursor-pointer transition shadow-md"
        >
          {isAdding ? <X size={14} /> : <Plus size={14} />}
          {isAdding ? "Close Editor" : "Add Promo Banner"}
        </button>
      </div>

      {/* Add Banner Editor (Form Collapse) */}
      {isAdding && (
        <form onSubmit={handleSaveBanner} className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-4 animate-fade-in">
          <div className="flex items-center gap-2 pb-3 border-b border-slate-800">
            <Sparkles className="text-rose-500" size={16} />
            <span className="text-sm font-extrabold text-white">Configure New Slider Card</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="text-xs font-bold text-slate-400 block mb-1">Badge Text (e.g. "Limited Time Sale", "Flash Deal" - Optional)</label>
              <input
                type="text"
                placeholder="e.g. FLASH DEAL"
                value={badge}
                onChange={e => setBadge(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-xs text-white focus:border-slate-500 outline-none"
              />
            </div>
            
            <div>
              <label className="text-xs font-bold text-slate-400 block mb-1">Banner Title (Primary Heading)</label>
              <input
                type="text"
                placeholder="e.g. Get All Codes at Flat 50% Rate"
                value={title}
                onChange={e => setTitle(e.target.value)}
                required
                className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-xs text-white focus:border-slate-500 outline-none"
              />
            </div>

            <div className="md:col-span-2">
              <label className="text-xs font-bold text-slate-400 block mb-1">Short Description (Sub-heading info)</label>
              <textarea
                placeholder="e.g. Securely checkout using any UPI payment app and get rapid delivery checks."
                value={subtitle}
                onChange={e => setSubtitle(e.target.value)}
                required
                rows={2}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-xs text-white focus:border-slate-500 outline-none resize-none"
              />
            </div>

            {/* Banner Image Uploader Area */}
            <div className="md:col-span-2 space-y-2">
              <div className="flex justify-between items-center">
                <label className="text-xs font-bold text-slate-400">Background Image/Illustration (autoBase64 or URL)</label>
                {imageUrl && (
                  <button
                    type="button"
                    onClick={() => setImageUrl("")}
                    className="text-xs font-bold text-rose-500 hover:text-rose-400 flex items-center gap-1 transition cursor-pointer"
                  >
                    <Trash2 size={12} /> Clear Background
                  </button>
                )}
              </div>
              
              <div className="grid grid-cols-1 sm:grid-cols-4 gap-4 animate-fade-in">
                {/* Drag-drop file container */}
                <div 
                  className="sm:col-span-3 border-2 border-dashed border-slate-800 hover:border-slate-700 bg-slate-950 rounded-xl p-6 flex flex-col items-center justify-center text-center cursor-pointer transition relative group"
                  onDragOver={(e) => e.preventDefault()}
                  onDrop={(e) => {
                    e.preventDefault();
                    const file = e.dataTransfer.files?.[0];
                    if (file) {
                      if (file.size > 3 * 1024 * 1024) {
                        showNotification("Image is too big (Max 3MB)", "error");
                        return;
                      }
                      const r = new FileReader();
                      r.onloadend = () => {
                        if (typeof r.result === "string") {
                          setImageUrl(r.result);
                          showNotification("Image loaded successfully");
                        }
                      };
                      r.readAsDataURL(file);
                    }
                  }}
                  onClick={() => document.getElementById("banner-image-upload")?.click()}
                >
                  <input 
                    id="banner-image-upload" 
                    type="file" 
                    accept="image/*" 
                    className="hidden" 
                    onChange={handleFileUpload}
                  />
                  <ImageIcon className="text-slate-500 group-hover:text-rose-500 mb-2 transition" size={24} />
                  <p className="text-slate-300 text-xs font-bold">Drag & drop banner slide image here, or browse local files</p>
                  <p className="text-[10px] text-slate-500 mt-1">Recommending wide aspects (Ratio 16:9 or similar), up to 3MB</p>
                </div>

                {/* Micro preview */}
                <div className="bg-slate-950 border border-slate-800 rounded-xl p-3 flex flex-col items-center justify-center min-h-[120px]">
                  {imageUrl ? (
                    <div className="w-full h-full flex flex-col items-center justify-center gap-2">
                      <div className="w-full h-16 bg-slate-900 rounded overflow-hidden flex items-center justify-center">
                        <img src={imageUrl} alt="Slide Preview" className="h-full w-full object-cover" />
                      </div>
                      <span className="text-[9px] text-emerald-400 font-bold font-mono">Image Prepared</span>
                    </div>
                  ) : (
                    <div className="text-center">
                      <div className="w-10 h-10 rounded bg-slate-900 border border-slate-800 flex items-center justify-center mx-auto text-slate-600 font-bold text-xs">NO</div>
                      <span className="text-[10px] text-slate-600 mt-2 block">No Custom Banner</span>
                    </div>
                  )}
                </div>
              </div>

              {/* Extra direct URL paste backup */}
              <div className="pt-1">
                <input
                  type="text"
                  placeholder="Or paste direct image address URL here instead..."
                  value={imageUrl}
                  onChange={e => setImageUrl(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-xs text-white focus:border-slate-500 outline-none"
                />
              </div>
            </div>

            <div>
              <label className="text-xs font-bold text-slate-400 block mb-1">Optional Banner Link/Action Identifier (URL or custom keyword)</label>
              <input
                type="text"
                placeholder="e.g. #gaming-section"
                value={link}
                onChange={e => setLink(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-xs text-white focus:border-slate-500 outline-none"
              />
            </div>
          </div>

          <div className="pt-4 border-t border-slate-800 flex justify-end gap-3">
            <button
              type="button"
              onClick={() => setIsAdding(false)}
              className="px-4 py-2 bg-slate-850 hover:bg-slate-800 text-slate-400 rounded-lg text-xs font-bold cursor-pointer transition"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-bold flex items-center gap-2 cursor-pointer transition shadow-md"
            >
              Save Promotional Banner Slide
            </button>
          </div>
        </form>
      )}

      {/* Active slide layout view / Live Preview simulation */}
      <div className="space-y-4">
        <h4 className="font-extrabold text-white text-xs uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
          <Sparkles size={12} className="text-rose-500" /> Currently Active Banners ({banners.length})
        </h4>

        {loading ? (
          <div className="py-12 text-center text-xs text-slate-500 font-mono animate-pulse">
            Connecting to Firestore banners catalog...
          </div>
        ) : banners.length === 0 ? (
          <div className="border border-dashed border-slate-800 bg-slate-950/20 py-12 rounded-2xl flex flex-col items-center justify-center text-center p-6">
            <AlertCircle size={28} className="text-slate-600 mb-2" />
            <p className="text-xs text-slate-400 font-bold mb-1">No dynamic promotional banners active</p>
            <p className="text-[11px] text-slate-500 max-w-sm">The homepage slider is automatically displaying its static default fallback cards. Click 'Add Promo Banner' above to set custom slides.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {banners.map((slide) => {
              // Custom inline background styling or Base64/url representation
              const bgStyle = slide.imageUrl.startsWith("data:") 
                ? { backgroundImage: `linear-gradient(to right, rgba(15,23,42,0.95), rgba(15,23,42,0.5)), url(${slide.imageUrl})` }
                : { backgroundImage: `linear-gradient(to right, rgba(15,23,42,0.95), rgba(15,23,42,0.6)), url(${slide.imageUrl})` };

              return (
                <div key={slide.id} className="relative bg-slate-900 border border-slate-800 p-5 rounded-2xl flex flex-col justify-between overflow-hidden group min-h-[160px]">
                  {/* Backdrop banner element image */}
                  <div 
                    className="absolute inset-0 bg-cover bg-center opacity-60 mix-blend-screen pointer-events-none group-hover:scale-105 transition-transform duration-700" 
                    style={bgStyle}
                  />

                  {/* Top line with badge & actions */}
                  <div className="relative z-10 flex justify-between items-start gap-4">
                    {slide.badge ? (
                      <span className="bg-rose-500/10 border border-rose-500/20 text-rose-400 text-[10px] font-black tracking-widest uppercase px-2 py-0.5 rounded">
                        {slide.badge}
                      </span>
                    ) : (
                      <span className="bg-slate-800/40 text-slate-500 text-[9px] px-1.5 py-0.5 rounded">Dynamic Slide</span>
                    )}

                    <button
                      onClick={() => handleDeleteBanner(slide.id)}
                      className="p-1.5 bg-slate-950/80 border border-slate-800 text-slate-400 hover:text-rose-500 hover:border-rose-950/40 rounded-lg transition-colors cursor-pointer"
                      title="Delete slide"
                    >
                      <Trash2 size={13} />
                    </button>
                  </div>

                  {/* Body elements */}
                  <div className="relative z-10 mt-4">
                    <h5 className="font-extrabold text-white text-sm tracking-tight leading-snug drop-shadow">
                      {slide.title}
                    </h5>
                    <p className="text-[11px] text-slate-400 mt-1 leading-normal max-w-[85%] drop-shadow-sm">
                      {slide.subtitle}
                    </p>
                  </div>

                  {/* Bottom link metadata */}
                  <div className="relative z-10 mt-3 pt-3 border-t border-slate-800/40 flex items-center justify-between text-[10px] text-slate-500">
                    <span>Created: {new Date(slide.createdAt).toLocaleDateString()}</span>
                    {slide.link && (
                      <span className="text-rose-400 font-bold flex items-center gap-0.5">
                        Target Link: {slide.link} <ChevronRight size={10} />
                      </span>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
