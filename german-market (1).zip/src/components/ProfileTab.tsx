import React, { useState } from "react";
import { UserProfile } from "../types";
import { doc, getDoc, setDoc } from "firebase/firestore";
import { db } from "../firebase";
import { LogIn, LogOut, UserPlus, Key, Fingerprint, ShieldCheck, Edit2, Check, X } from "lucide-react";

interface ProfileTabProps {
  userProfile: UserProfile;
  setUserProfile: (profile: UserProfile) => void;
}

export default function ProfileTab({ userProfile, setUserProfile }: ProfileTabProps) {
  const [mode, setMode] = useState<"view" | "login" | "register" | "change_pin">("view");
  const [isEditingName, setIsEditingName] = useState(false);
  const [editNameValue, setEditNameValue] = useState("");

  const [loginUid, setLoginUid] = useState("");
  const [loginPin, setLoginPin] = useState("");

  const [regName, setRegName] = useState("");
  const [regEmail, setRegEmail] = useState("");
  const [regPin, setRegPin] = useState("");

  // PIN change state fields
  const [newProfilePin, setNewProfilePin] = useState("");
  const [confirmNewProfilePin, setConfirmNewProfilePin] = useState("");

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [confirmSignOutOpen, setConfirmSignOutOpen] = useState(false);

  const handleChangePin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (newProfilePin.trim().length !== 6) return setError("PIN must be 6 digits");
    if (newProfilePin.trim() !== confirmNewProfilePin.trim()) return setError("PINs do not match");
    setLoading(true);
    setError(null);
    try {
      const updated = {
        ...userProfile,
        pin: newProfilePin.trim()
      };
      await setDoc(doc(db, "users", userProfile.id), updated);
      setUserProfile(updated);
      localStorage.setItem("gm_user_profile", JSON.stringify(updated));
      setMode("view");
      setNewProfilePin("");
      setConfirmNewProfilePin("");
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    const sanitizedUid = loginUid.trim();
    const sanitizedPin = loginPin.trim();

    if (!sanitizedUid || !sanitizedPin) return setError("Please enter UID and PIN");
    setLoading(true);
    setError(null);
    try {
      // Secure Admin Specific Credentials Verification
      if ((sanitizedUid === "G-5002473" || sanitizedUid === "rbxcompany.in@gmail.com") && sanitizedPin === "452585") {
        const adminProfile: UserProfile = {
          id: "G-5002473",
          name: "Subhajit (Admin)",
          isGuest: false,
          email: "rbxcompany.in@gmail.com",
          pin: "452585",
          createdAt: new Date().toISOString()
        };
        setUserProfile(adminProfile);
        localStorage.setItem("gm_user_profile", JSON.stringify(adminProfile));
        localStorage.setItem("gm_admin_unlocked", "true");
        setMode("view");
        return;
      }

      const uDoc = await getDoc(doc(db, "users", sanitizedUid));
      if (uDoc.exists()) {
        const u = uDoc.data() as UserProfile;
        if (u.pin === sanitizedPin) {
          setUserProfile(u);
          localStorage.setItem("gm_user_profile", JSON.stringify(u));
          setMode("view");
        } else {
          setError("Incorrect 6-digit PIN");
        }
      } else {
        setError("Account not found with this UID");
      }
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    if (regPin.trim().length !== 6) return setError("PIN must be 6 digits");
    setLoading(true);
    setError(null);
    try {
      const u: UserProfile = {
        ...userProfile,
        name: regName.trim() || userProfile.name,
        isGuest: false,
        email: regEmail.trim(),
        pin: regPin.trim(),
        createdAt: userProfile.createdAt || new Date().toISOString()
      };
      await setDoc(doc(db, "users", userProfile.id), u);
      setUserProfile(u);
      localStorage.setItem("gm_user_profile", JSON.stringify(u));
      setMode("view");
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleSignOut = () => {
    localStorage.removeItem("gm_user_profile");
    window.location.reload();
  };

  if (mode === "login") {
    return (
      <div className="max-w-md mx-auto space-y-6 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-6 rounded-3xl shadow-sm">
        <h2 className="text-xl font-bold flex gap-2 items-center text-slate-800 dark:text-slate-100">
          <Fingerprint className="text-rose-600" /> Find Old Account
        </h2>

        <div className="bg-slate-50 dark:bg-slate-950 p-4 rounded-2xl border border-slate-100 dark:border-slate-850 text-xs text-slate-500 space-y-1">
          <p className="font-bold text-slate-700 dark:text-slate-350 flex items-center gap-1.5">
            <ShieldCheck size={14} className="text-rose-650" />
            <span>Account Verification & Recovery</span>
          </p>
          <p className="text-[11px] leading-relaxed">
            Enter your unique recovery UID / Email and 6-digit Security PIN to retrieve your account details. Authorized administrators can authenticate here to unlock the <strong>Admin Panel</strong>.
          </p>
        </div>

        {error && <div className="text-rose-500 text-xs bg-rose-500/10 p-2.5 rounded-xl font-medium">{error}</div>}
        <form onSubmit={handleLogin} className="space-y-4">
          <div>
            <label className="text-xs font-bold text-slate-500 block mb-1">Account UID or Email ID:</label>
            <input type="text" required value={loginUid} onChange={e => setLoginUid(e.target.value)} className="w-full p-3 bg-slate-50 border border-slate-200 dark:bg-slate-950 dark:border-slate-800 rounded-xl text-sm outline-none focus:border-slate-400" placeholder="UID from old profile" />
          </div>
          <div>
            <label className="text-xs font-bold text-slate-500 block mb-1">6-Digit PIN:</label>
            <input type="password" maxLength={6} required value={loginPin} onChange={e => setLoginPin(e.target.value.replace(/\D/g,''))} className="w-full p-3 bg-slate-50 border border-slate-200 dark:bg-slate-950 dark:border-slate-800 rounded-xl text-sm tracking-widest outline-none focus:border-slate-400" placeholder="••••••" />
            <div className="flex justify-end mt-1">
              <button 
                type="button" 
                onClick={() => {
                  const uid = loginUid || userProfile.id;
                  const name = userProfile.name;
                  const whatsappText = `Hello Support, I forgot my PIN.\n\n*UID:* ${uid}\n*Name (optional):* ${name}\n*Description:* Please help me reset my 6-digit PIN.`;
                  window.open(`https://wa.me/4915510539752?text=${encodeURIComponent(whatsappText)}`, "_blank");
                }}
                className="text-[10px] text-rose-600 hover:text-rose-500 font-bold"
              >
                Forgot PIN?
              </button>
            </div>
          </div>
          <div className="flex gap-2 pt-2">
            <button type="button" onClick={() => setMode("view")} className="w-full py-3 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold transition">Cancel</button>
            <button type="submit" disabled={loading} className="w-full py-3 bg-rose-600 hover:bg-rose-500 text-white rounded-xl text-xs font-bold transition shadow-sm">{loading ? "Finding..." : "Login"}</button>
          </div>
        </form>
      </div>
    );
  }

  if (mode === "register") {
    return (
      <div className="max-w-md mx-auto space-y-6 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-6 rounded-3xl">
        <h2 className="text-xl font-bold flex gap-2 items-center text-slate-800 dark:text-slate-100">
          <Key className="text-emerald-600" /> Secure Profile
        </h2>
        <p className="text-xs text-slate-500">Protect your current guest profile with a 6-digit PIN so you can recover your history later.</p>
        {error && <div className="text-rose-500 text-xs bg-rose-500/10 p-2 rounded">{error}</div>}
        <form onSubmit={handleRegister} className="space-y-4">
          <div>
            <label className="text-xs font-bold text-slate-500 block mb-1">Display Name:</label>
            <input type="text" required value={regName} onChange={e => setRegName(e.target.value)} className="w-full p-3 bg-slate-50 border border-slate-200 dark:bg-slate-950 dark:border-slate-800 rounded-xl text-sm outline-none focus:border-slate-400" placeholder="Your Name" />
          </div>
          <div>
            <label className="text-xs font-bold text-slate-500 block mb-1">Email Addres (Optional but recommended):</label>
            <input type="email" value={regEmail} onChange={e => setRegEmail(e.target.value)} className="w-full p-3 bg-slate-50 border border-slate-200 dark:bg-slate-950 dark:border-slate-800 rounded-xl text-sm outline-none focus:border-slate-400" placeholder="name@example.com" />
          </div>
          <div>
            <label className="text-xs font-bold text-slate-500 block mb-1">Create 6-Digit PIN:</label>
            <input type="password" maxLength={6} required value={regPin} onChange={e => setRegPin(e.target.value.replace(/\D/g, ''))} className="w-full p-3 bg-slate-50 border border-slate-200 dark:bg-slate-950 dark:border-slate-800 rounded-xl text-sm tracking-widest outline-none focus:border-slate-400" placeholder="••••••" />
          </div>
          <div className="flex gap-2 pt-2">
            <button type="button" onClick={() => setMode("view")} className="w-full py-3 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold transition">Cancel</button>
            <button type="submit" disabled={loading} className="w-full py-3 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold transition shadow-sm">{loading ? "Saving..." : "Secure Account"}</button>
          </div>
        </form>
      </div>
    );
  }

  if (mode === "change_pin") {
    return (
      <div className="max-w-md mx-auto space-y-6 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-6 rounded-3xl">
        <h2 className="text-xl font-bold flex gap-2 items-center text-slate-800 dark:text-slate-100">
          <Key className="text-rose-600" /> Change Security PIN
        </h2>
        <p className="text-xs text-slate-500">Update the 6-digit passcode connected to your account.</p>
        {error && <div className="text-rose-500 text-xs bg-rose-500/10 p-2 rounded">{error}</div>}
        <form onSubmit={handleChangePin} className="space-y-4">
          <div>
            <label className="text-xs font-bold text-slate-500 block mb-1">New 6-Digit PIN (Only Numbers):</label>
            <input 
              type="password" 
              maxLength={6} 
              required 
              value={newProfilePin} 
              onChange={e => setNewProfilePin(e.target.value.replace(/\D/g, ''))} 
              className="w-full p-3 bg-slate-50 border border-slate-200 dark:bg-slate-950 dark:border-slate-800 rounded-xl text-sm tracking-widest outline-none focus:border-slate-400" 
              placeholder="••••••" 
            />
          </div>
          <div>
            <label className="text-xs font-bold text-slate-500 block mb-1">Confirm New PIN:</label>
            <input 
              type="password" 
              maxLength={6} 
              required 
              value={confirmNewProfilePin} 
              onChange={e => setConfirmNewProfilePin(e.target.value.replace(/\D/g, ''))} 
              className="w-full p-3 bg-slate-50 border border-slate-200 dark:bg-slate-950 dark:border-slate-800 rounded-xl text-sm tracking-widest outline-none focus:border-slate-400" 
              placeholder="••••••" 
            />
          </div>
          <div className="flex gap-2 pt-2">
            <button type="button" onClick={() => { setError(null); setMode("view"); }} className="w-full py-3 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold transition">Cancel</button>
            <button type="submit" disabled={loading} className="w-full py-3 bg-rose-600 hover:bg-rose-500 text-white rounded-xl text-xs font-bold transition shadow-sm">{loading ? "Updating..." : "Update PIN"}</button>
          </div>
        </form>
      </div>
    );
  }

  const handleSaveName = async () => {
    if (!editNameValue.trim() || editNameValue.trim() === userProfile.name) {
      setIsEditingName(false);
      return;
    }
    const updated = { ...userProfile, name: editNameValue.trim() };
    setUserProfile(updated);
    localStorage.setItem("gm_user_profile", JSON.stringify(updated));
    try { 
      await setDoc(doc(db, "users", userProfile.id), updated, { merge: true }); 
    } catch (e) { 
      console.error(e); 
    }
    setIsEditingName(false);
  };

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-6 rounded-3xl flex flex-col md:flex-row items-start md:items-center justify-between gap-4 shadow-sm">
        <div>
          {isEditingName ? (
            <div className="flex items-center gap-2 mb-1">
              <input 
                type="text" 
                value={editNameValue} 
                onChange={e => setEditNameValue(e.target.value)} 
                className="font-black text-xl text-slate-900 dark:text-slate-50 bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded px-2 py-1 outline-none w-48"
                autoFocus
              />
              <button onClick={handleSaveName} className="p-1.5 bg-emerald-100 hover:bg-emerald-200 text-emerald-700 rounded-md transition"><Check size={16}/></button>
              <button onClick={() => setIsEditingName(false)} className="p-1.5 bg-slate-100 hover:bg-slate-200 text-slate-600 rounded-md transition"><X size={16}/></button>
            </div>
          ) : (
            <h2 className="text-2xl font-black text-slate-900 dark:text-slate-50 flex items-center gap-2">
              {userProfile.name}
              <button onClick={() => { setEditNameValue(userProfile.name); setIsEditingName(true); }} className="text-slate-400 hover:text-slate-600 transition"><Edit2 size={16}/></button>
            </h2>
          )}
          <p className="text-xs text-slate-500 mt-1 flex items-center gap-1"><Fingerprint size={12}/> Account UID: <span className="font-mono text-rose-600 font-bold">{userProfile.id}</span></p>
          {userProfile.email && <p className="text-xs text-slate-500 mt-0.5">Email: {userProfile.email}</p>}
          
          <div className="mt-3">
            {userProfile.pin ? (
              <span className="inline-flex items-center gap-1 bg-emerald-100 dark:bg-emerald-900/30 text-emerald-700 dark:text-emerald-400 text-[10px] px-2 py-1 rounded-md font-bold"><ShieldCheck size={12}/> Profile Secured</span>
            ) : (
              <span className="inline-flex items-center gap-1 bg-amber-100 dark:bg-amber-900/30 text-amber-700 dark:text-amber-400 text-[10px] px-2 py-1 rounded-md font-bold">Guest Profile (Unsecured)</span>
            )}
          </div>
        </div>

        <div className="flex flex-col gap-2 w-full md:w-auto">
          {userProfile.pin && (
            <button onClick={() => { setError(null); setMode("change_pin"); }} className="bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-800 dark:text-white py-2.5 px-4 rounded-xl text-xs font-bold shadow-sm flex justify-center items-center gap-1.5 transition-colors cursor-pointer">
              <Key size={14}/> Change Security PIN
            </button>
          )}
          <button onClick={() => setMode("login")} className="bg-slate-900 dark:bg-slate-800 text-white py-2.5 px-4 rounded-xl text-xs font-bold shadow-sm flex justify-center items-center gap-1.5 transition-colors cursor-pointer">
            <LogIn size={14}/> Find Old Account
          </button>
        </div>
      </div>

    </div>
  );
}
