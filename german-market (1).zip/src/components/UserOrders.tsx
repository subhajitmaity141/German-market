import React, { useState, useEffect } from "react";
import { collection, query, where, onSnapshot, doc, getDoc } from "firebase/firestore";
import { db, handleFirestoreError, OperationType } from "../firebase";
import { Order, UserProfile } from "../types";
import { 
  ShoppingBag, ShieldAlert, Clock, CheckCircle, XCircle, Tag, Copy, 
  Search, Calendar, Mail, ArrowRight, CornerDownRight 
} from "lucide-react";

interface UserOrdersProps {
  user: UserProfile;
}

export default function UserOrders({ user }: UserOrdersProps) {
  const [userOrders, setUserOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // States for the 10-digit lookup
  const [lookupId, setLookupId] = useState("");
  const [lookupOrder, setLookupOrder] = useState<Order | null>(null);
  const [lookupLoading, setLookupLoading] = useState(false);
  const [lookupError, setLookupError] = useState<string | null>(null);

  const [copiedOrderId, setCopiedOrderId] = useState<string | null>(null);
  const [copiedCouponId, setCopiedCouponId] = useState<string | null>(null);

  // Copy helper
  const handleCopy = (text: string, type: "order" | "coupon") => {
    navigator.clipboard.writeText(text);
    if (type === "order") {
      setCopiedOrderId(text);
      setTimeout(() => setCopiedOrderId(null), 2000);
    } else {
      setCopiedCouponId(text);
      setTimeout(() => setCopiedCouponId(null), 2000);
    }
  };

  // 1. Fetch user specific orders
  useEffect(() => {
    if (!user || !user.id) {
      setLoading(false);
      return;
    }
    setLoading(true);
    setError(null);

    const ordersCol = collection(db, "orders");
    const q = query(ordersCol, where("userEmailOrId", "==", user.id));

    const unsubscribe = onSnapshot(
      q,
      (snapshot) => {
        const list: Order[] = [];
        snapshot.forEach((doc) => {
          list.push(doc.data() as Order);
        });
        // Sort newest first
        list.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
        setUserOrders(list);
        setLoading(false);
      },
      (err) => {
        setLoading(false);
        try {
          handleFirestoreError(err, OperationType.LIST, "orders");
        } catch (e: any) {
          setError(e.message);
        }
      }
    );

    return () => unsubscribe();
  }, [user.id]);

  // 2. Lookup single order by 10-digit ID
  const handleLookup = async (e: React.FormEvent) => {
    e.preventDefault();
    const sanitized = lookupId.trim();
    if (sanitized.length !== 10 || !/^\d{10}$/.test(sanitized)) {
      setLookupError("Please enter a valid 10-digit Order ID.");
      setLookupOrder(null);
      return;
    }

    setLookupLoading(true);
    setLookupError(null);
    setLookupOrder(null);

    try {
      const orderRef = doc(db, "orders", sanitized);
      const snapshot = await getDoc(orderRef);
      if (snapshot.exists()) {
        setLookupOrder(snapshot.data() as Order);
      } else {
        setLookupError("No order found with this tracking ID.");
      }
    } catch (err) {
      setLookupError("Failed to fetch order. Inspect network connection.");
    } finally {
      setLookupLoading(false);
    }
  };

  return (
    <div className="space-y-8">
      {/* 10-Digit Tracking Section */}
      <div className="bg-slate-900 text-white rounded-3xl p-6 shadow-md border border-slate-800">
        <h3 className="text-base font-bold mb-1 flex items-center gap-2">
          <Search size={18} className="text-rose-500 stroke-[2.5]" />
          <span>Search & Track details</span>
        </h3>
        <p className="text-xs text-slate-400 mb-5">
          Enter any 10-digit Order ID to track its real-time approval status and retrieve code blocks.
        </p>

        <form onSubmit={handleLookup} className="flex gap-2 mb-4">
          <input
            type="text"
            maxLength={10}
            placeholder="e.g. 5820194857"
            value={lookupId}
            onChange={(e) => setLookupId(e.target.value.replace(/\D/g, ""))}
            className="flex-grow px-4 py-3 bg-slate-950 border border-slate-800 focus:border-slate-700 focus:outline-none rounded-xl text-sm font-mono text-white placeholder-slate-600"
          />
          <button
            type="submit"
            disabled={lookupLoading}
            className="bg-rose-600 hover:bg-rose-500 text-white px-5 py-3 rounded-xl text-sm font-bold transition-all shrink-0 cursor-pointer disabled:opacity-50"
          >
            {lookupLoading ? "Searching..." : "Track Order"}
          </button>
        </form>

        {lookupError && (
          <div className="bg-rose-500/10 text-rose-400 p-3 rounded-xl text-xs font-semibold flex items-center gap-1.5 border border-rose-500/20">
            <XCircle size={14} />
            <span>{lookupError}</span>
          </div>
        )}

        {lookupOrder && (
          <div className="mt-5 pt-5 border-t border-slate-800/80 animate-fade-in bg-slate-950/40 p-4 rounded-2xl border border-slate-800/60">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between mb-4 gap-2">
              <div>
                <span className="text-[10px] uppercase font-bold text-slate-500 bg-slate-900 px-2 py-0.5 rounded">Track Result</span>
                <h4 className="text-sm font-bold text-slate-100 font-mono flex items-center gap-1.5 mt-1">
                  ID: #{lookupOrder.id}
                  <button onClick={() => handleCopy(lookupOrder.id, "order")} className="text-slate-500 hover:text-slate-300">
                    <Copy size={12} />
                  </button>
                  {copiedOrderId === lookupOrder.id && (
                    <span className="text-[10px] text-emerald-400 font-sans font-medium">Copied!</span>
                  )}
                </h4>
              </div>
              <div>
                <span className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-bold ${
                  lookupOrder.status === "Pending"
                    ? "bg-amber-500/10 text-amber-400"
                    : lookupOrder.status === "Approved"
                      ? "bg-emerald-500/10 text-emerald-400"
                      : "bg-rose-500/10 text-rose-400"
                }`}>
                  <span className="w-1.5 h-1.5 rounded-full bg-current animate-pulse"></span>
                  {lookupOrder.status}
                </span>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4 text-xs mb-4">
              <div>
                <div className="text-slate-500">Brand Name</div>
                <div className="font-bold text-slate-200 mt-0.5">{lookupOrder.brand}</div>
                {(lookupOrder.rewardType || lookupOrder.brand.toLowerCase() === "bgmi" || lookupOrder.brand.toLowerCase() === "free fire max") && (
                  <span className="inline-block text-[10px] font-bold text-rose-400 bg-rose-950/40 border border-rose-900/10 px-1.5 py-0.5 rounded mt-1">
                    🎁 {lookupOrder.rewardAmount ?? (lookupOrder.brand.toLowerCase() === "bgmi" ? Math.round(lookupOrder.faceValue * 0.8) : Math.round(lookupOrder.faceValue * 1.25))} {lookupOrder.rewardType ?? (lookupOrder.brand.toLowerCase() === "bgmi" ? "UC" : "Diamonds")} Pack
                  </span>
                )}
              </div>
              <div>
                <div className="text-slate-500">Delivery Mail</div>
                <div className="font-semibold text-slate-200 mt-0.5 truncate" title={lookupOrder.email}>{lookupOrder.email}</div>
              </div>
              <div>
                <div className="text-slate-500">Transaction UTR</div>
                <div className="font-mono text-slate-200 mt-0.5">{lookupOrder.utr}</div>
              </div>
              <div>
                <div className="text-slate-500">Paid amount</div>
                <div className="font-mono font-bold text-rose-400 mt-0.5">₹{lookupOrder.paidAmount} <span className="text-[10px] line-through text-slate-600 font-medium font-sans">₹{lookupOrder.faceValue}</span></div>
              </div>
            </div>

            {/* If approved - Displays Coupon Code */}
            {lookupOrder.status === "Approved" ? (
              <div className="bg-emerald-500/10 border border-emerald-500/20 rounded-xl p-4 mt-2">
                <div className="text-xs text-slate-400 font-medium">Delivered Coupon Code:</div>
                <div className="flex items-center justify-between gap-3 bg-slate-950 p-2.5 rounded-lg border border-slate-800/80 mt-1.5">
                  <span className="font-mono font-black text-emerald-400 text-sm tracking-widest truncate">
                    {lookupOrder.couponCode}
                  </span>
                  <button
                    onClick={() => handleCopy(lookupOrder.couponCode || "", "coupon")}
                    className="shrink-0 flex items-center gap-1 bg-emerald-600 hover:bg-emerald-500 text-slate-950 font-bold px-2.5 py-1 rounded text-xs transition-colors cursor-pointer"
                  >
                    <Copy size={11} className="stroke-[2.5]" />
                    <span>{copiedCouponId === lookupOrder.couponCode ? "Copied" : "Copy"}</span>
                  </button>
                </div>
              </div>
            ) : lookupOrder.status === "Pending" ? (
              <div className="bg-amber-500/5 border border-amber-500/10 rounded-xl p-4 mt-2 flex gap-2">
                <Clock size={16} className="text-amber-500 shrink-0 mt-0.5" />
                <p className="text-[11px] text-slate-400 leading-relaxed">
                  Verification takes 2 to 10 working minutes. Safe delivery of your code is processed directly once the admin confirms your payment UTR unique reference.
                </p>
              </div>
            ) : (
              <div className="bg-rose-500/5 border border-rose-500/10 rounded-xl p-4 mt-2 flex gap-2">
                <XCircle size={16} className="text-rose-500 shrink-0 mt-0.5" />
                <p className="text-[11px] text-slate-400 leading-relaxed">
                  Your payment verification failed or decline code was registered. Please double check if you provided correct UTR or contact help support.
                </p>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Sync User History Grid list */}
      <div className="bg-white dark:bg-slate-950 border border-slate-100 dark:border-slate-800 rounded-3xl p-6 shadow-sm">
        <h3 className="text-lg font-bold text-slate-800 dark:text-slate-100 mb-1 flex items-center gap-2">
          <ShoppingBag size={20} className="text-rose-600 stroke-[2.5]" />
          <span>My Order Profile</span>
        </h3>
        <div className="flex items-center justify-between mb-6 border-b border-slate-100 dark:border-slate-800 pb-3">
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Your orders history under Profile ID: <span className="font-mono text-rose-600 font-semibold">{user.id}</span>
          </p>
          <button
            onClick={() => {
              navigator.clipboard.writeText(user.id);
              alert("Profile UID copied!");
            }}
            className="flex items-center gap-1 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-600 dark:text-slate-300 px-2 py-1 rounded text-[10px] font-bold cursor-pointer transition-colors"
          >
            <Copy size={12} />
            Copy UID
          </button>
        </div>

        {error && (
          <div className="mb-4 bg-red-50 text-red-600 p-3 rounded-xl text-xs flex gap-1.5 border border-red-100 font-mono">
            <ShieldAlert size={16} className="shrink-0" />
            <span>Diagnostic: {error}</span>
          </div>
        )}

        {loading ? (
          <div className="py-12 text-center text-xs text-slate-500">
            Syncing order database...
          </div>
        ) : userOrders.length === 0 ? (
          <div className="py-12 text-center">
            <ShoppingBag className="mx-auto text-slate-300 dark:text-slate-700 mb-2" size={36} />
            <p className="text-xs text-slate-500 dark:text-slate-400 font-semibold">You have not ordered anything yet.</p>
            <p className="text-[11px] text-slate-400 dark:text-slate-500 mt-1">Select a brand card above and initiate instant checkout.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {userOrders.map((order) => {
              const whatsappOrderText = `Hello Support,
I need help with my recent order.

*UID:* ${user.id}
*Name:* ${user.name}
*Order ID:* ${order.id}
*Brand:* ${order.brand}
*Face Value:* ₹${order.faceValue}
*Status:* ${order.status}`;
              const whatsappOrderLink = `https://wa.me/4915510539752?text=${encodeURIComponent(whatsappOrderText)}`;

              return (
              <div 
                key={order.id} 
                className="p-5 bg-slate-50 dark:bg-slate-900 rounded-2xl border border-slate-200/50 dark:border-slate-800/80 flex flex-col justify-between"
              >
                <div>
                  <div className="flex justify-between items-start mb-3 gap-2">
                    <div>
                      <h4 className="font-bold text-slate-900 dark:text-white text-sm">{order.brand}</h4>
                      {(order.rewardType || order.brand.toLowerCase() === "bgmi" || order.brand.toLowerCase() === "free fire max") && (
                        <span className="inline-block text-[10px] font-bold text-rose-600 dark:text-rose-400 bg-rose-50 dark:bg-rose-950/20 px-1.5 py-0.5 rounded border border-rose-100/20 mt-1">
                          🎁 {order.rewardAmount ?? (order.brand.toLowerCase() === "bgmi" ? Math.round(order.faceValue * 0.8) : Math.round(order.faceValue * 1.25))} {order.rewardType ?? (order.brand.toLowerCase() === "bgmi" ? "UC" : "Diamonds")} Delivery Content
                        </span>
                      )}
                      <div className="flex items-center gap-2 mt-1">
                        <p className="text-[10px] text-slate-400 dark:text-slate-500">Order ID: #{order.id}</p>
                        <button
                          onClick={() => handleCopy(order.id, "order")}
                          className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 transition-colors"
                          title="Copy Order ID"
                        >
                          <Copy size={10} />
                        </button>
                        {copiedOrderId === order.id && (
                          <span className="text-[9px] text-emerald-500 font-medium">Copied!</span>
                        )}
                      </div>
                    </div>
                    <span className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[10px] font-bold ${
                      order.status === "Pending" 
                        ? "bg-amber-100/60 text-amber-700 dark:bg-amber-950/20 dark:text-amber-400"
                        : order.status === "Approved"
                          ? "bg-emerald-100/60 text-emerald-700 dark:bg-emerald-950/20 dark:text-emerald-400"
                          : "bg-rose-100/60 text-rose-700 dark:bg-rose-950/20 dark:text-rose-400"
                    }`}>
                      {order.status}
                    </span>
                  </div>

                  <div className="space-y-1 text-xs text-slate-600 dark:text-slate-300 pb-3 border-b border-slate-200/40 dark:border-slate-800/60">
                    <div className="flex justify-between items-center bg-slate-50 dark:bg-slate-950/50 p-1.5 rounded-md mb-2">
                      <span className="flex items-center gap-1.5 text-slate-400 text-[10px] font-medium"><Clock size={12}/> Purchase Date:</span>
                      <span className="text-[10px] text-slate-500 font-mono">
                        {new Date(order.createdAt).toLocaleString(undefined, {
                          year: 'numeric', month: 'short', day: 'numeric',
                          hour: '2-digit', minute: '2-digit'
                        })}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400 text-[11px]">Denomination face value</span>
                      <span className="font-medium">₹{order.faceValue}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400 text-[11px]">Paid online rate (50%)</span>
                      <span className="font-bold text-rose-600">₹{order.paidAmount}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400 text-[11px]">Submit UTR ID</span>
                      <span className="font-mono">{order.utr}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400 text-[11px]">Delivery email</span>
                      <span className="truncate max-w-[150px] font-medium" title={order.email}>{order.email}</span>
                    </div>
                  </div>
                </div>

                <div className="mt-4">
                  {order.status === "Approved" ? (
                    <div className="space-y-1">
                      <div className="text-[10px] text-slate-400 font-bold flex items-center gap-0.5">
                        <Tag size={10} className="text-emerald-600" />
                        <span>COUPON CODE RECEIVED</span>
                      </div>
                      <div className="flex items-center justify-between gap-2 bg-white dark:bg-slate-950 p-2 rounded-lg border border-slate-200 dark:border-slate-800 mt-1">
                        <span className="font-mono font-black text-emerald-600 dark:text-emerald-400 text-xs truncate max-w-[140px] tracking-widest">{order.couponCode}</span>
                        <button 
                          onClick={() => handleCopy(order.couponCode || "", "coupon")}
                          className="shrink-0 bg-slate-900 text-white dark:bg-slate-800 dark:text-slate-100 text-[10px] font-bold px-2 py-1 rounded hover:bg-slate-800"
                        >
                          Copy
                        </button>
                      </div>
                    </div>
                  ) : order.status === "Pending" ? (
                    <div className="text-[10px] text-amber-600 dark:text-amber-400 bg-amber-500/5 p-2 rounded border border-amber-500/10 flex gap-1 items-start">
                      <Clock size={11} className="shrink-0 mt-0.5" />
                      <span>Deliver in 2-10 working minute. Under verification check.</span>
                    </div>
                  ) : (
                    <div className="text-[10px] text-rose-500 bg-rose-500/5 p-2 rounded border border-rose-500/10 flex gap-1 items-start">
                      <XCircle size={11} className="shrink-0 mt-0.5" />
                      <span>Order verification failed. Please contact admin service.</span>
                    </div>
                  )}
                  <div className="mt-4 pt-3 border-t border-slate-200/50 dark:border-slate-800/80">
                    <a 
                      href={whatsappOrderLink} 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="w-full flex items-center justify-center gap-1.5 bg-emerald-50 hover:bg-emerald-100 dark:bg-emerald-900/10 dark:hover:bg-emerald-900/20 text-emerald-700 dark:text-emerald-400 py-2 rounded-xl text-[11px] font-bold transition-colors cursor-pointer border border-emerald-200 dark:border-emerald-800/50"
                    >
                      <span>Help / Support for this Order</span>
                      <ArrowRight size={12} />
                    </a>
                  </div>
                </div>
              </div>
            )})}
          </div>
        )}
      </div>
    </div>
  );
}
