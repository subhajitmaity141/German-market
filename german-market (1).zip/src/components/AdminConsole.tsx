import React, { useState, useEffect } from "react";
import { collection, onSnapshot, doc, updateDoc, setDoc } from "firebase/firestore";
import { db, handleFirestoreError, OperationType } from "../firebase";
import { Order, UserProfile } from "../types";
import { 
  ShieldCheck, Check, X, Tag, Clipboard, Clock, AlertCircle, ShoppingBag, 
  Search, Mail, User, ShieldAlert, Users, Key, Monitor, Activity, Layers, Copy,
  Menu, ChevronDown, Image as ImageIcon
} from "lucide-react";
import BrandManagement from "./BrandManagement";
import BannerManagement from "./BannerManagement";

interface AdminConsoleProps {
  onBack?: () => void;
  currentUserProfile?: UserProfile | null;
  onUpdateCurrentUserProfile?: (profile: UserProfile) => void;
}

export default function AdminConsole({ onBack, currentUserProfile, onUpdateCurrentUserProfile }: AdminConsoleProps) {
  const [orders, setOrders] = useState<Order[]>([]);
  const [users, setUsers] = useState<UserProfile[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<"dashboard" | "orders" | "users" | "brands" | "banners">("dashboard");
  
  // States for entering coupon code during approval
  const [couponInputs, setCouponInputs] = useState<{ [orderId: string]: string }>({});
  const [approvingOrderId, setApprovingOrderId] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState<"All" | "Pending" | "Approved" | "Declined">("All");

  // User PIN editing
  const [editingPinForId, setEditingPinForId] = useState<string | null>(null);
  const [newPinValue, setNewPinValue] = useState<string>("");
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  // Custom premuim notifications state
  const [notification, setNotification] = useState<{ message: string; type: "success" | "error" } | null>(null);
  const [declineConfirmId, setDeclineConfirmId] = useState<string | null>(null);

  const showNotification = (message: string, type: "success" | "error" = "success") => {
    setNotification({ message, type });
    setTimeout(() => {
      setNotification((prev) => (prev?.message === message ? null : prev));
    }, 4500);
  };

  useEffect(() => {
    const ordersCol = collection(db, "orders");
    const unsubscribeOrders = onSnapshot(
      ordersCol,
      (snapshot) => {
        const orderList: Order[] = [];
        snapshot.forEach((doc) => {
          orderList.push(doc.data() as Order);
        });
        orderList.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
        setOrders(orderList);
        setLoading(false);
      },
      (err) => {
        setLoading(false);
        try {
          handleFirestoreError(err, OperationType.LIST, "orders");
        } catch (e: any) {
          setError(e.message);
        }
      }
    );

    const usersCol = collection(db, "users");
    const unsubscribeUsers = onSnapshot(
      usersCol,
      (snapshot) => {
        const userList: UserProfile[] = [];
        snapshot.forEach((doc) => {
          userList.push(doc.data() as UserProfile);
        });
        setUsers(userList);
      },
      (err) => {
        console.error("Failed to fetch users:", err);
        try {
          handleFirestoreError(err, OperationType.LIST, "users");
        } catch (e: any) {
          setError("Admin access failed for users directory. Please check Admin permissions in Firebase rules.");
        }
      }
    );

    return () => {
      unsubscribeOrders();
      unsubscribeUsers();
    };
  }, []);

  // Handle Approve action
  const handleApprove = async (orderId: string) => {
    const code = couponInputs[orderId]?.trim() || "";
    if (!code) {
      showNotification("Please enter a valid Gift Card Copy/Coupon Code first!", "error");
      return;
    }

    try {
      setError(null);
      const orderRef = doc(db, "orders", orderId);
      await updateDoc(orderRef, {
        status: "Approved",
        couponCode: code
      });
      
      setApprovingOrderId(null);
      setCouponInputs(prev => {
        const copy = { ...prev };
        delete copy[orderId];
        return copy;
      });
      showNotification("Order approved & code sent successfully!", "success");
    } catch (err) {
      try {
        handleFirestoreError(err, OperationType.UPDATE, `orders/${orderId}`);
      } catch (e: any) {
        setError(e.message);
        showNotification(`Approval failed: ${e.message}`, "error");
      }
    }
  };

  // Handle Decline action
  const handleDecline = async (orderId: string) => {
    try {
      setError(null);
      const orderRef = doc(db, "orders", orderId);
      await updateDoc(orderRef, {
        status: "Declined"
      });
      showNotification("Order declined successfully!", "success");
    } catch (err) {
      try {
        handleFirestoreError(err, OperationType.UPDATE, `orders/${orderId}`);
      } catch (e: any) {
        setError(e.message);
        showNotification(`Decline failed: ${e.message}`, "error");
      }
    }
  };

  const handleUpdatePin = async (uid: string) => {
    if (!newPinValue || newPinValue.length !== 6) {
      showNotification("PIN must be 6 digits.", "error");
      return;
    }

    try {
      const userRef = doc(db, "users", uid);
      await setDoc(userRef, {
        pin: newPinValue
      }, { merge: true });

      if (currentUserProfile && uid === currentUserProfile.id && onUpdateCurrentUserProfile) {
        onUpdateCurrentUserProfile({
          ...currentUserProfile,
          pin: newPinValue
        });
      }

      setEditingPinForId(null);
      setNewPinValue("");
      showNotification("PIN changed successfully!", "success");
    } catch (err: any) {
      showNotification(`Failed to update PIN: ${err.message}`, "error");
    }
  };

  const handleToggleBlock = async (uid: string, isBlocked: boolean) => {
    try {
      const userRef = doc(db, "users", uid);
      await setDoc(userRef, {
        isBlocked: !isBlocked
      }, { merge: true });

      showNotification(isBlocked ? "User unblocked successfully!" : "User blocked successfully!", "success");
    } catch (err: any) {
      showNotification(`Failed to update block status: ${err.message}`, "error");
    }
  };

  // Filtered orders list
  const filteredOrders = orders.filter((order) => {
    const matchesSearch = 
      order.id.includes(searchTerm) || 
      order.brand.toLowerCase().includes(searchTerm.toLowerCase()) || 
      order.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
      order.utr.includes(searchTerm) ||
      (order.playerId && order.playerId.includes(searchTerm));
      
    const matchesStatus = statusFilter === "All" || order.status === statusFilter;
    
    return matchesSearch && matchesStatus;
  });

  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const todayOrders = orders.filter(o => new Date(o.createdAt).getTime() >= today.getTime());
  const todayRevenue = todayOrders.filter(o => o.status === "Approved").reduce((sum, o) => sum + o.paidAmount, 0);
  const totalRevenue = orders.filter(o => o.status === "Approved").reduce((sum, o) => sum + o.paidAmount, 0);

  return (
    <div className="bg-slate-950 text-slate-50 border border-slate-800 rounded-3xl shadow-2xl relative">
      {/* Premium custom floating notification */}
      {notification && (
        <div className={`fixed top-4 right-4 z-[9999] flex items-center gap-2.5 px-4.5 py-3 rounded-2xl shadow-2xl border text-xs font-bold font-sans animate-bounce-short backdrop-blur-md
          ${notification.type === "success" 
            ? "bg-emerald-950/95 text-emerald-400 border-emerald-500/30" 
            : "bg-rose-950/95 text-rose-450 border-rose-500/30"
          }
        `}>
          <div className="w-2 h-2 rounded-full bg-current animate-pulse"></div>
          <span>{notification.message}</span>
        </div>
      )}

      {/* Admin Header */}
      <div className="bg-slate-900 border-b border-slate-800 p-6 flex flex-col lg:flex-row lg:items-center justify-between gap-4 rounded-t-3xl">
        <div>
          <h2 className="text-xl font-bold text-white flex items-center gap-2">
            <ShieldCheck className="text-rose-500 stroke-[2.5]" size={24} />
            <span className="bg-clip-text text-transparent bg-gradient-to-r from-white to-slate-400">Black Market Terminal</span>
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            System Administration • Control Panel access authorized
          </p>
        </div>

        <div className="flex flex-col lg:flex-row lg:items-center gap-4 w-full lg:w-auto">
          {onBack && (
            <button
              onClick={onBack}
              className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-white text-xs font-bold rounded-lg border border-slate-700 transition-colors hidden lg:block"
            >
              Back to App
            </button>
          )}

          {/* Mobile Tab Toggle (3-line Hamburger Menu) */}
          <div className="lg:hidden relative w-full">
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="flex items-center justify-between w-full px-4 py-3 bg-slate-950 text-slate-200 text-xs font-bold rounded-xl border border-slate-800 hover:bg-slate-900 transition-colors cursor-pointer"
            >
              <div className="flex items-center gap-2">
                <Menu size={16} className="text-rose-500" />
                <span>Menu: {
                  activeTab === "dashboard" ? "Dashboard" : 
                  activeTab === "orders" ? "Orders" : 
                  activeTab === "users" ? "User Management" :
                  activeTab === "brands" ? "Brand Management" : "Banner Management"
                }</span>
              </div>
              <ChevronDown size={14} className={`text-slate-400 transition-transform duration-200 ${mobileMenuOpen ? "rotate-180" : ""}`} />
            </button>

            {mobileMenuOpen && (
              <div className="absolute left-0 right-0 mt-2 bg-slate-900 border border-slate-800 rounded-xl shadow-2xl z-50 p-1.5 flex flex-col gap-1">
                {[
                  { id: "dashboard", icon: <Activity size={14}/>, label: "Dashboard" },
                  { id: "orders", icon: <ShoppingBag size={14}/>, label: "Orders" },
                  { id: "users", icon: <Users size={14}/>, label: "User Mgmt" },
                  { id: "brands", icon: <Layers size={14}/>, label: "Brand Mgmt" },
                  { id: "banners", icon: <ImageIcon size={14}/>, label: "Banner Mgmt" }
                ].map(tab => (
                  <button
                    key={tab.id}
                    onClick={() => {
                      setActiveTab(tab.id as any);
                      setMobileMenuOpen(false);
                    }}
                    className={`flex items-center gap-2.5 px-4 py-3 rounded-lg text-xs font-bold transition-all w-full text-left cursor-pointer ${
                      activeTab === tab.id 
                        ? "bg-slate-800 text-white shadow-sm"
                        : "text-slate-400 hover:bg-slate-800/50 hover:text-white"
                    }`}
                  >
                    {tab.icon}
                    {tab.label}
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Desktop Tab Navigation */}
          <div className="hidden lg:flex gap-2 bg-slate-950 p-1.5 rounded-xl border border-slate-800 shrink-0 overflow-x-auto">
            {[
              { id: "dashboard", icon: <Activity size={14}/>, label: "Dashboard" },
              { id: "orders", icon: <ShoppingBag size={14}/>, label: "Orders" },
              { id: "users", icon: <Users size={14}/>, label: "User Mgmt" },
              { id: "brands", icon: <Layers size={14}/>, label: "Brand Mgmt" },
              { id: "banners", icon: <ImageIcon size={14}/>, label: "Banner Mgmt" }
            ].map(tab => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`flex items-center gap-1.5 px-4 py-2 rounded-lg text-xs font-bold transition-all cursor-pointer whitespace-nowrap ${
                  activeTab === tab.id 
                    ? "bg-slate-800 text-white shadow-sm"
                    : "text-slate-500 hover:text-slate-300"
                }`}
              >
                {tab.icon}
                {tab.label}
              </button>
            ))}
          </div>
        </div>
      </div>

      {error && (
        <div className="m-6 bg-red-950/30 text-red-400 p-3.5 rounded-xl text-xs flex gap-2 border border-red-900/40 font-mono">
          <ShieldAlert size={16} className="shrink-0" />
          <span>Error (Diagnostic): {error}</span>
        </div>
      )}

      <div className="p-6">
        {loading ? (
          <div className="py-20 text-center text-xs text-slate-500 font-mono animate-pulse">
            Establishing secure connection to database...
          </div>
        ) : (
          <>
            {/* Dashboard Tab */}
            {activeTab === "dashboard" && (
              <div className="space-y-6 animate-fade-in">
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                  <div className="bg-slate-900 border border-slate-800 p-5 rounded-2xl relative overflow-hidden">
                    <div className="text-slate-400 text-xs font-bold mb-1 uppercase tracking-wider relative z-10">Total Users</div>
                    <div className="text-3xl font-black text-white relative z-10">{users.length}</div>
                    <Users size={64} className="absolute -bottom-4 -right-2 text-slate-800/50" />
                  </div>
                  <div className="bg-slate-900 border border-slate-800 p-5 rounded-2xl relative overflow-hidden">
                    <div className="text-slate-400 text-xs font-bold mb-1 uppercase tracking-wider relative z-10">Total Orders</div>
                    <div className="text-3xl font-black text-white relative z-10">{orders.length}</div>
                    <ShoppingBag size={64} className="absolute -bottom-4 -right-2 text-slate-800/50" />
                  </div>
                  <div className="bg-slate-900 border border-emerald-900/30 p-5 rounded-2xl relative overflow-hidden">
                    <div className="text-emerald-500/80 text-xs font-bold mb-1 uppercase tracking-wider relative z-10">Today's Revenue</div>
                    <div className="text-3xl font-black text-emerald-400 relative z-10">₹{todayRevenue}</div>
                    <div className="text-[10px] text-emerald-400/60 mt-1 relative z-10">{todayOrders.length} orders today</div>
                  </div>
                  <div className="bg-slate-900 border border-rose-900/30 p-5 rounded-2xl relative overflow-hidden">
                    <div className="text-rose-500/80 text-xs font-bold mb-1 uppercase tracking-wider relative z-10">Total Revenue</div>
                    <div className="text-3xl font-black text-rose-400 relative z-10">₹{totalRevenue}</div>
                  </div>
                </div>

                <div className="bg-slate-900 border border-slate-800 p-6 rounded-2xl">
                  <h3 className="font-bold text-white mb-4">Recent Activity Logs</h3>
                  <div className="space-y-3">
                    {orders.slice(0, 5).map(o => (
                      <div key={o.id} className="flex justify-between items-center bg-slate-950 p-3 rounded-xl border border-slate-800/60">
                        <div className="text-xs">
                          <span className="font-mono text-slate-400">[{new Date(o.createdAt).toLocaleTimeString()}]</span>
                          <span className="mx-2 font-bold text-slate-200">Order #{o.id}</span>
                          <span className="text-slate-500">by {o.userEmailOrId} for {o.brand}</span>
                        </div>
                        <span className={`text-[10px] font-bold px-2 py-1 rounded-md ${
                          o.status === 'Approved' ? 'bg-emerald-900/20 text-emerald-400' : 
                          o.status === 'Pending' ? 'bg-amber-900/20 text-amber-400' : 'bg-red-900/20 text-red-400'
                        }`}>
                          {o.status}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {/* Orders Tab */}
            {activeTab === "orders" && (
              <div className="animate-fade-in">
                {/* Control Filters */}
                <div className="flex flex-col sm:flex-row gap-3 mb-6">
                  {/* Search */}
                  <div className="relative flex-grow">
                    <Search className="absolute left-3.5 top-3.5 text-slate-400" size={16} />
                    <input
                      type="text"
                      placeholder="Search Order ID, email, player ID, brand, UTR..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="w-full pl-10 pr-4 py-3 bg-slate-900 border border-slate-800 rounded-xl text-xs text-slate-100 focus:outline-none focus:border-slate-600"
                    />
                  </div>

                  {/* Filter buttons */}
                  <div className="flex gap-1.5 shrink-0 bg-slate-900 p-1 rounded-xl border border-slate-800">
                    {(["All", "Pending", "Approved", "Declined"] as const).map((status) => (
                      <button
                        key={status}
                        onClick={() => setStatusFilter(status)}
                        className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all cursor-pointer ${
                          statusFilter === status 
                            ? "bg-slate-800 text-white shadow-sm"
                            : "text-slate-500 hover:text-slate-300"
                        }`}
                      >
                        {status}
                      </button>
                    ))}
                  </div>
                </div>

                {filteredOrders.length === 0 ? (
                  <div className="py-12 border-2 border-dashed border-slate-800 rounded-2xl text-center">
                    <ShoppingBag className="mx-auto text-slate-700 mb-2" size={32} />
                    <p className="text-xs text-slate-400 font-medium">No purchase orders found</p>
                  </div>
                ) : (
                  <div className="overflow-x-auto">
                    <table className="w-full text-left border-collapse min-w-[800px]">
                      <thead>
                        <tr className="border-b border-slate-800 text-xs font-semibold text-slate-500 uppercase tracking-wider">
                          <th className="py-3 px-4">Order Specs</th>
                          <th className="py-3 px-4">Customer Info & Device</th>
                          <th className="py-3 px-4">Payment UTR</th>
                          <th className="py-3 px-4">Status</th>
                          <th className="py-3 px-4 text-right">Actions</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-800 text-xs">
                        {filteredOrders.map((order) => (
                          <tr key={order.id} className="hover:bg-slate-900/50 transition-colors">
                            {/* Order Specs */}
                            <td className="py-4 px-4">
                              <div className="font-bold text-white font-mono flex items-center gap-2 group">
                                #{order.id}
                                <button onClick={() => navigator.clipboard.writeText(order.id)} className="opacity-0 group-hover:opacity-100 text-slate-500 hover:text-slate-300 transition" title="Copy Order ID"><Copy size={12}/></button>
                              </div>
                              <div className="font-semibold text-slate-300 mt-0.5">{order.brand}</div>
                              {order.playerId && (
                                <div className="text-[10px] text-rose-400 mt-1 font-mono bg-rose-950/30 px-1 inline-flex items-center gap-1 rounded group">
                                  UID: {order.playerId}
                                  <button onClick={() => navigator.clipboard.writeText(order.playerId || '')} className="opacity-0 group-hover:opacity-100 text-rose-500 hover:text-rose-300 transition" title="Copy UID"><Copy size={10}/></button>
                                </div>
                              )}
                              {(order.rewardType || order.brand.toLowerCase() === "bgmi" || order.brand.toLowerCase() === "free fire max") && (
                                <div className="mt-1">
                                  <span className="text-[10px] text-emerald-400 font-bold bg-emerald-950/40 px-1.5 py-0.5 rounded border border-emerald-900/30">
                                    Deliver: {order.rewardAmount ?? (order.brand.toLowerCase() === "bgmi" ? Math.round(order.faceValue * 0.8) : Math.round(order.faceValue * 1.25))} {order.rewardType ?? (order.brand.toLowerCase() === "bgmi" ? "UC" : "Diamonds")}
                                  </span>
                                </div>
                              )}
                              <div className="flex gap-2 text-[10px] mt-1">
                                <span className="text-slate-500">Value: ₹{order.faceValue}</span>
                                <span className="text-rose-500 font-medium">Paid: ₹{order.paidAmount}</span>
                              </div>
                            </td>

                            {/* Customer Info */}
                            <td className="py-4 px-4 max-w-[200px]">
                              <div className="flex items-center gap-1 text-slate-300 font-medium truncate group relative">
                                <User size={12} className="text-slate-500 shrink-0" />
                                <span className="truncate" title={order.userEmailOrId}>{order.userEmailOrId}</span>
                                <button onClick={() => navigator.clipboard.writeText(order.userEmailOrId)} className="opacity-0 group-hover:opacity-100 text-slate-500 hover:text-slate-300 transition absolute -right-4 bg-slate-900 border border-slate-800 rounded p-0.5" title="Copy User ID"><Copy size={10}/></button>
                              </div>
                              <div className="flex items-center gap-1 text-slate-500 mt-0.5 truncate group relative">
                                <Mail size={12} className="text-slate-500 shrink-0" />
                                <span className="truncate text-[10px]" title={order.email}>{order.email}</span>
                                <button onClick={() => navigator.clipboard.writeText(order.email)} className="opacity-0 group-hover:opacity-100 text-slate-500 hover:text-slate-300 transition absolute -right-4 bg-slate-900 border border-slate-800 rounded p-0.5" title="Copy Email"><Copy size={10}/></button>
                              </div>
                              <div className="flex items-center gap-1 text-slate-600 mt-1 truncate">
                                <Monitor size={10} className="shrink-0" />
                                <span className="truncate text-[9px] font-mono" title={order.deviceInfo || 'N/A'}>
                                  {order.deviceInfo || 'Unknown Device'}
                                </span>
                              </div>
                              <div className="flex items-center gap-1 text-[10px] text-slate-400 mt-1.5 font-medium">
                                <Clock size={10} className="shrink-0 text-slate-500" />
                                {new Date(order.createdAt).toLocaleString(undefined, {
                                  year: 'numeric', month: 'short', day: 'numeric',
                                  hour: '2-digit', minute: '2-digit', second: '2-digit'
                                })}
                              </div>
                            </td>

                            {/* UTR */}
                            <td className="py-4 px-4 font-mono text-slate-300">
                              <div className="bg-slate-900 px-2.5 py-1.5 rounded-lg border border-slate-800 max-w-max flex items-center gap-2 group">
                                <span className="font-semibold">{order.utr}</span>
                                <button onClick={() => navigator.clipboard.writeText(order.utr)} className="opacity-0 group-hover:opacity-100 text-slate-500 hover:text-slate-300 transition" title="Copy UTR"><Copy size={12}/></button>
                              </div>
                            </td>

                            {/* Status & Code */}
                            <td className="py-4 px-4">
                              <span className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[11px] font-bold ${
                                order.status === "Pending" 
                                  ? "bg-amber-950/20 text-amber-500"
                                  : order.status === "Approved"
                                    ? "bg-emerald-950/20 text-emerald-500"
                                    : "bg-red-950/20 text-red-500"
                              }`}>
                                <span className="w-1.5 h-1.5 rounded-full bg-current"></span>
                                {order.status}
                              </span>

                              {order.status === "Approved" && order.couponCode && (
                                <div className="mt-1.5 flex items-center gap-1.5 bg-emerald-950/20 p-1.5 rounded border border-emerald-900/30">
                                  <Tag size={12} className="text-emerald-500 shrink-0" />
                                  <span className="font-mono text-[10px] font-bold text-emerald-400 truncate tracking-wide max-w-[150px]">
                                    {order.couponCode}
                                  </span>
                                </div>
                              )}
                            </td>

                            {/* Actions */}
                            <td className="py-4 px-4 text-right">
                              {order.status === "Pending" ? (
                                <div className="flex flex-col items-end gap-2">
                                  {approvingOrderId === order.id ? (
                                    <div className="space-y-1.5 w-48 text-left">
                                      <label className="text-[10px] font-semibold text-slate-400">Insert Coupon / Game Code:</label>
                                      <input
                                        type="text"
                                        value={couponInputs[order.id] || ""}
                                        onChange={(e) => setCouponInputs({ ...couponInputs, [order.id]: e.target.value })}
                                        placeholder="e.g. K39D-LS84"
                                        className="w-full px-2 py-1 bg-slate-900 border border-slate-700 rounded font-mono text-[11px] text-white focus:outline-none focus:border-slate-500"
                                      />
                                      <div className="flex gap-1 justify-end">
                                        <button
                                          onClick={() => setApprovingOrderId(null)}
                                          className="px-2 py-1 bg-slate-800 text-slate-400 rounded text-[10px] hover:bg-slate-700"
                                        >
                                          Cancel
                                        </button>
                                        <button
                                          onClick={() => handleApprove(order.id)}
                                          className="px-2 py-1 bg-emerald-600 text-white font-bold rounded text-[10px] hover:bg-emerald-500"
                                        >
                                          Submit
                                        </button>
                                      </div>
                                    </div>
                                  ) : (
                                    <div className="flex gap-1.5 items-center justify-end">
                                      {declineConfirmId === order.id ? (
                                        <div className="flex gap-1.5 items-center bg-slate-900 border border-slate-850 p-1.5 rounded-lg">
                                          <button
                                            onClick={() => {
                                              handleDecline(order.id);
                                              setDeclineConfirmId(null);
                                            }}
                                            className="bg-rose-600 hover:bg-rose-500 text-white font-bold py-1 px-2 rounded text-[10px] transition-colors cursor-pointer animate-pulse whitespace-nowrap"
                                          >
                                            Decline? Confirm
                                          </button>
                                          <button
                                            onClick={() => setDeclineConfirmId(null)}
                                            className="text-slate-400 hover:text-white text-[10.5px] px-1 font-bold"
                                          >
                                            X
                                          </button>
                                        </div>
                                      ) : (
                                        <>
                                          <button
                                            onClick={() => {
                                              setApprovingOrderId(order.id);
                                              setCouponInputs({ ...couponInputs, [order.id]: `${order.brand.toUpperCase().replace(/\s+/g, '-')}-${Math.floor(1000 + Math.random() * 9000)}` });
                                            }}
                                            className="bg-emerald-600 hover:bg-emerald-500 text-white font-semibold py-1 px-2.5 rounded-lg text-[11px] flex items-center gap-1 transition-colors cursor-pointer"
                                          >
                                            <Check size={12} />
                                            <span>Approve</span>
                                          </button>
                                          <button
                                            onClick={() => setDeclineConfirmId(order.id)}
                                            className="bg-slate-800 hover:bg-slate-700 text-slate-300 font-semibold py-1 px-2.5 rounded-lg text-[11px] flex items-center gap-1 transition-colors cursor-pointer"
                                          >
                                            <X size={12} />
                                            <span>Decline</span>
                                          </button>
                                        </>
                                      )}
                                    </div>
                                  )}
                                </div>
                              ) : (
                                <span className="text-[10px] text-slate-500 italic">Settled</span>
                              )}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>
            )}

            {/* User Mgmt Tab */}
            {activeTab === "users" && (
              <div className="animate-fade-in">
                {users.length === 0 ? (
                  <div className="py-12 border-2 border-dashed border-slate-800 rounded-2xl text-center">
                    <Users className="mx-auto text-slate-700 mb-2" size={32} />
                    <p className="text-xs text-slate-400 font-medium">No users or guest profiles found in system</p>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {users.map(u => (
                      <div key={u.id} className="bg-slate-900 border border-slate-800 p-4 rounded-xl flex flex-col gap-3 relative overflow-hidden group">
                        <div className="flex justify-between items-start z-10 relative">
                          <div>
                            <div className="font-bold text-white text-sm">{u.name}</div>
                            <div className="text-[10px] text-slate-400 font-mono mt-0.5">{u.id}</div>
                          </div>
                          <div className="flex gap-1.5 flex-wrap">
                            {u.isBlocked && (
                              <div className="bg-rose-950 text-rose-500 px-2 py-1 rounded text-[10px] font-bold border border-rose-900/30">Blocked</div>
                            )}
                            {u.pin ? (
                              <div className="bg-emerald-950/30 text-emerald-500 px-2 py-1 rounded text-[10px] font-bold border border-emerald-900/30">Registered</div>
                            ) : (
                              <div className="bg-slate-800 text-slate-400 px-2 py-1 rounded text-[10px] font-bold">Guest Profile</div>
                            )}
                          </div>
                        </div>
                        
                        <div className="text-[11px] text-slate-400 space-y-1 z-10 relative">
                          <div className="flex items-center gap-1.5"><Mail size={12}/> Email: {u.email || 'N/A'}</div>
                          <div className="flex items-center gap-1.5"><Clock size={12}/> Registered: {u.createdAt ? new Date(u.createdAt).toLocaleString() : 'Unknown'}</div>
                          <div className="flex items-center gap-1.5"><Monitor size={12}/> Device: <span className="font-mono text-[9px] truncate max-w-[200px]">{u.deviceInfo || 'Unknown'}</span></div>
                        </div>

                        <div className="pt-2 border-t border-slate-800 mt-1 z-10 relative flex flex-col sm:flex-row gap-2 items-start sm:items-center justify-between">
                          <div className="flex items-center gap-1.5 text-xs text-rose-450 font-semibold">
                            <Key size={12}/> {u.pin ? "Security PIN Active" : "No PIN Setup"}
                          </div>
                          
                          <div className="flex items-center gap-2 flex-wrap">
                            <button 
                              onClick={() => handleToggleBlock(u.id, !!u.isBlocked)}
                              className={`text-[10px] px-2.5 py-1.5 rounded font-bold cursor-pointer transition-colors ${
                                u.isBlocked 
                                  ? "bg-emerald-950/40 hover:bg-emerald-900/60 text-emerald-400 border border-emerald-500/10" 
                                  : "bg-rose-950/40 hover:bg-rose-900/60 text-rose-400 border border-rose-500/10"
                              }`}
                            >
                              {u.isBlocked ? "Unblock" : "Block"}
                            </button>

                            {editingPinForId === u.id ? (
                              <div className="flex items-center gap-1.5">
                                <input 
                                  title="Must be 6 digits"
                                  type="text" 
                                  maxLength={6} 
                                  placeholder="6-digit PIN"
                                  value={newPinValue}
                                  onChange={e => setNewPinValue(e.target.value.replace(/\D/g, ''))}
                                  className="w-16 px-1.5 py-1 bg-slate-950 border border-slate-700 text-white rounded outline-none text-[11px] font-mono"
                                />
                                <button onClick={() => handleUpdatePin(u.id)} className="text-[10px] bg-rose-600 text-white px-2 py-1 rounded font-bold hover:bg-rose-500 cursor-pointer">Save</button>
                                <button onClick={() => { setEditingPinForId(null); setNewPinValue(""); }} className="text-[10px] text-slate-400 hover:text-white cursor-pointer">X</button>
                              </div>
                            ) : (
                              <button 
                                onClick={() => { setEditingPinForId(u.id); setNewPinValue(""); }}
                                className="text-[10px] bg-slate-800 text-slate-300 px-2.5 py-1.5 rounded hover:bg-slate-700 font-bold cursor-pointer transition-colors"
                              >
                                {u.pin ? "PIN" : "Set PIN"}
                              </button>
                            )}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}

            {/* Brands Mgmt Tab */}
            {activeTab === "brands" && (
              <div className="animate-fade-in -mx-6 -mt-6">
                 <BrandManagement />
              </div>
            )}

            {/* Banners Mgmt Tab */}
            {activeTab === "banners" && (
              <div className="animate-fade-in text-slate-100">
                 <BannerManagement />
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}

