import React from "react";
import { Brand } from "../types";
import { Tag, ArrowRight } from "lucide-react";
import { motion } from "motion/react";

interface BrandCardProps {
  brand: Brand;
  onSelect: (brand: Brand, amount?: number) => void;
}

const BrandCard: React.FC<BrandCardProps> = ({ brand, onSelect }) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 15 }}
      animate={{ opacity: 1, y: 0 }}
      whileHover={{ y: -4, scale: 1.02 }}
      transition={{ duration: 0.2 }}
      className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-100 dark:border-slate-800 shadow-sm hover:shadow-md overflow-hidden flex flex-col h-full cursor-pointer"
      style={{ contentVisibility: "auto" }}
      onClick={() => onSelect(brand)}
    >
      {/* Brand Header Colored Block */}
      <div 
        className="h-28 relative flex items-center justify-center overflow-hidden"
        style={{ 
          background: `linear-gradient(135deg, ${brand.bgHex}dd, ${brand.bgHex})` 
        }}
      >
        {/* Abstract Background pattern */}
        <div className="absolute inset-0 opacity-10 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-white via-black to-black"></div>
        
        {/* Brand visual name */}
        <div className="text-white font-extrabold text-2xl tracking-tight drop-shadow-sm text-center px-4">
          {brand.name.split(" ")[0]}
        </div>

        {/* 50% Promo Tag Badge */}
        <div className="absolute top-3 right-3 bg-white/95 text-xs font-black px-2.5 py-1 rounded-full shadow-sm flex items-center gap-1" style={{ color: brand.bgHex }}>
          <Tag size={12} className="stroke-[3]" />
          50% RATE
        </div>
      </div>

      {/* Brand Information */}
      <div className="p-5 flex flex-col flex-grow">
        <h3 className="font-semibold text-slate-800 dark:text-slate-100 text-base mb-1 tracking-tight">
          {brand.name}
        </h3>
        <p className="text-xs text-slate-500 dark:text-slate-400 mb-4 capitalize">
          Category: {brand.category}
        </p>

        {/* Demominations listing */}
        <div className="mb-5 flex-grow">
          <div className="text-xs text-slate-400 dark:text-slate-500 mb-1.5 font-medium">Available Cards:</div>
          <div className="flex flex-wrap gap-1.5">
            {brand.popularDenominations.slice(0, 4).map((denom) => (
              <button 
                key={denom} 
                onClick={(e) => {
                  e.stopPropagation();
                  onSelect(brand, denom);
                }}
                className="text-xs font-mono font-bold bg-slate-50 hover:bg-slate-100 dark:bg-slate-800/60 dark:hover:bg-slate-800 text-slate-700 hover:text-slate-900 dark:text-slate-300 dark:hover:text-white px-2.5 py-1 rounded border border-slate-200 dark:border-slate-700 transition-colors cursor-pointer"
              >
                ₹{denom}
              </button>
            ))}
            {brand.popularDenominations.length > 4 && (
              <span className="text-[10px] font-sans text-slate-400 flex items-center px-1">
                +{brand.popularDenominations.length - 4} more
              </span>
            )}
          </div>
        </div>

        {/* Purchase Action Button */}
        <button
          onClick={(e) => {
             e.stopPropagation();
             onSelect(brand);
          }}
          className="w-full flex items-center justify-center gap-2 bg-slate-900 border border-transparent dark:bg-slate-800 hover:bg-slate-800 dark:hover:bg-slate-700 text-white font-semibold py-3 px-4 rounded-xl text-sm transition-colors duration-150 cursor-pointer"
        >
          <span>Purchase Card</span>
          <ArrowRight size={14} />
        </button>  
      </div>
    </motion.div>
  );
};

export default BrandCard;
