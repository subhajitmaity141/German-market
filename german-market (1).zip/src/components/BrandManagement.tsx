import React, { useState, useEffect } from "react";
import { collection, onSnapshot, doc, setDoc, deleteDoc, updateDoc } from "firebase/firestore";
import { db } from "../firebase";
import { Brand, BrandProduct } from "../types";
import { Plus, Edit2, Trash2, Save, X, Image as ImageIcon, Settings } from "lucide-react";
import { BRANDS as fallbackBrands } from "../brandsData";

export default function BrandManagement() {
  const [brands, setBrands] = useState<Brand[]>([]);
  const [loading, setLoading] = useState(true);
  const [editingBrand, setEditingBrand] = useState<Brand | null>(null);

  // Non-blocking premium alerts
  const [notification, setNotification] = useState<{ message: string; type: "success" | "error" } | null>(null);
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);
  const [isSyncConfirmOpen, setIsSyncConfirmOpen] = useState(false);

  const showNotification = (message: string, type: "success" | "error" = "success") => {
    setNotification({ message, type });
    setTimeout(() => {
      setNotification(prev => prev?.message === message ? null : prev);
    }, 4500);
  };

  useEffect(() => {
    const unsub = onSnapshot(collection(db, "brands"), (snap) => {
      const fetched: Brand[] = [];
      snap.forEach(d => fetched.push(d.data() as Brand));
      if (fetched.length === 0) {
        setBrands(fallbackBrands);
      } else {
        setBrands(fetched);
      }
      setLoading(false);
    }, (err) => {
      console.error("Firestore Error in BrandManagement snapshot:", err);
      setLoading(false);
    });
    return unsub;
  }, []);

  const handleSyncToFirebase = async () => {
    try {
      for (const b of fallbackBrands) {
          const bFixed: Brand = { ...b, products: [] };
          if (b.popularDenominations) {
              bFixed.products = b.popularDenominations.map(den => {
                  let name = `₹${den} Code`;
                  let rewardType = "Gift Card";
                  let rewardAmount = den;

                  if (b.id === "bgmi") {
                      rewardType = "UC";
                      if (den === 500) { rewardAmount = 380; name = "380 UC Pack"; }
                      else if (den === 750) { rewardAmount = 660; name = "660 UC Pack"; }
                      else if (den === 1500) { rewardAmount = 1800; name = "1800 UC Hero Pack"; }
                      else if (den === 3800) { rewardAmount = 3850; name = "3850 UC Pro Pack"; }
                      else if (den === 5000) { rewardAmount = 8100; name = "8100 UC Mythic Pack"; }
                      else { rewardAmount = Math.round(den * 0.8); name = `${rewardAmount} UC Pack`; }
                  } else if (b.id === "freefire") {
                      rewardType = "Diamonds";
                      if (den === 500) { rewardAmount = 530; name = "530 Diamonds"; }
                      else if (den === 800) { rewardAmount = 1080; name = "1080 Diamonds"; }
                      else if (den === 1600) { rewardAmount = 2200; name = "2200 Premium Diamonds"; }
                      else if (den === 4000) { rewardAmount = 5600; name = "5600 Legendary Diamonds"; }
                      else { rewardAmount = Math.round(den * 1.25); name = `${rewardAmount} FF Diamonds`; }
                  } else if (b.id === "valorant") {
                      rewardType = "Points";
                      if (den === 500) { rewardAmount = 500; name = "500 Valorant Points"; }
                      else if (den === 800) { rewardAmount = 1000; name = "1000 Valorant Points"; }
                      else if (den === 1600) { rewardAmount = 2050; name = "2050 Valorant Points"; }
                      else if (den === 4000) { rewardAmount = 5350; name = "5350 Valorant Points"; }
                      else if (den === 8000) { rewardAmount = 11000; name = "11000 Valorant Points"; }
                      else { rewardAmount = den; name = `${rewardAmount} Valorant Points`; }
                  }

                  return {
                      id: Math.random().toString(36).substr(2, 9),
                      name,
                      originalPrice: den * 2,
                      sellingPrice: den,
                      discountPercentage: 50,
                      stock: 100,
                      rewardType,
                      rewardAmount
                  };
              });
          }
        await setDoc(doc(db, "brands", b.id), bFixed);
      }
      showNotification("Successfully synced default brands to Database!", "success");
      setIsSyncConfirmOpen(false);
    } catch (e: any) {
      showNotification(`Sync failed: ${e.message}`, "error");
    }
  };

  const handleSaveBrand = async () => {
    if (!editingBrand) return;
    try {
      if (!editingBrand.id) {
        editingBrand.id = editingBrand.name.toLowerCase().replace(/[^a-z0-9]/g, '-');
      }
      await setDoc(doc(db, "brands", editingBrand.id), editingBrand);
      setEditingBrand(null);
      showNotification("Brand updated successfully!", "success");
    } catch (e: any) {
      showNotification(`Error saving brand: ${e.message}`, "error");
    }
  };

  const handleDeleteBrand = async (id: string) => {
    try {
      await deleteDoc(doc(db, "brands", id));
      showNotification("Brand deleted successfully!", "success");
      setDeleteConfirmId(null);
    } catch (e: any) {
      showNotification(`Failed to delete: ${e.message}`, "error");
    }
  };

  const addProductToEditingBrand = () => {
    if (!editingBrand) return;
    const newProduct: BrandProduct = {
      id: Math.random().toString(36).substr(2, 9),
      name: "",
      originalPrice: 0,
      sellingPrice: 0,
      discountPercentage: 0,
      stock: 10,
      rewardType: "",
      rewardAmount: 0
    };
    setEditingBrand({ ...editingBrand, products: [...(editingBrand.products || []), newProduct] });
  };
  
  const handleProductChange = (index: number, field: keyof BrandProduct, value: string | number) => {
      if (!editingBrand || !editingBrand.products) return;
      const updatedProducts = [...editingBrand.products];
      const prod = { ...updatedProducts[index] };
      (prod as any)[field] = value;
      
      if (field === 'originalPrice' || field === 'sellingPrice') {
         if (prod.originalPrice > 0 && prod.sellingPrice >= 0) {
            prod.discountPercentage = Math.round(((prod.originalPrice - prod.sellingPrice) / prod.originalPrice) * 100);
         }
      }
      
      updatedProducts[index] = prod;
      setEditingBrand({ ...editingBrand, products: updatedProducts });
  };

  const removeProduct = (index: number) => {
      if (!editingBrand || !editingBrand.products) return;
      const updatedProducts = [...editingBrand.products];
      updatedProducts.splice(index, 1);
      setEditingBrand({ ...editingBrand, products: updatedProducts });
  };

  return (
    <div className="p-6 relative">
      {/* Premium custom floating notification */}
      {notification && (
        <div className={`fixed top-4 right-4 z-[9999] flex items-center gap-2.5 px-4.5 py-3 rounded-2xl shadow-2xl border text-xs font-bold font-sans animate-bounce-short backdrop-blur-md
          ${notification.type === "success" 
            ? "bg-emerald-950/95 text-emerald-400 border-emerald-500/30" 
            : "bg-rose-950/95 text-rose-450 border-rose-500/30"
          }
        `}>
          <div className="w-2 h-2 rounded-full bg-current animate-pulse"></div>
          <span>{notification.message}</span>
        </div>
      )}

      <div className="flex justify-between items-center mb-6">
        <div>
          <h3 className="text-xl font-bold text-white">Brand Management</h3>
          <p className="text-xs text-slate-400 mt-1">Add or update brands and their products</p>
        </div>
        <div className="flex gap-2 items-center">
            {isSyncConfirmOpen ? (
              <div className="flex gap-1.5 items-center bg-slate-900 border border-slate-800 p-1.5 rounded-lg select-none">
                <span className="text-[10px] text-slate-400 font-bold px-1 font-mono">Overwrite DB?</span>
                <button 
                  onClick={handleSyncToFirebase}
                  className="px-2.5 py-1 bg-rose-600 hover:bg-rose-500 text-white rounded text-[10px] font-black cursor-pointer"
                >
                  Yes, Sync
                </button>
                <button 
                  onClick={() => setIsSyncConfirmOpen(false)}
                  className="px-1 text-slate-400 hover:text-white text-[11px] font-bold cursor-pointer"
                >
                  X
                </button>
              </div>
            ) : (
              <button 
                onClick={() => setIsSyncConfirmOpen(true)}
                className="px-4 py-2 bg-slate-800 text-slate-300 rounded-lg text-xs font-bold hover:bg-slate-700 cursor-pointer"
              >
                Sync Defaults
              </button>
            )}
            <button 
            onClick={() => setEditingBrand({ id: '', name: '', category: 'gaming', imageUrl: '', textColor: 'text-white', bgHex: '#1e293b', rateText: '50% OFF', popularDenominations: [], products: [], requiresPlayerId: false, requiresEmail: true })}
            className="px-4 py-2 bg-rose-600 text-white rounded-lg text-xs font-bold flex items-center gap-2 hover:bg-rose-500 cursor-pointer"
            >
            <Plus size={16} /> Add Brand
            </button>
        </div>
      </div>

      {editingBrand && (
        <div className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-slate-900 border border-slate-700 rounded-2xl w-full max-w-3xl my-8">
            <div className="p-4 border-b border-slate-800 flex justify-between items-center bg-slate-950 rounded-t-2xl">
              <h4 className="font-bold text-white">{editingBrand.id ? 'Edit Brand' : 'New Brand'}</h4>
              <button onClick={() => setEditingBrand(null)} className="text-slate-400 hover:text-white"><X size={20}/></button>
            </div>
            
            <div className="p-6 space-y-6 max-h-[70vh] overflow-y-auto">
              {/* Brand Basics */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="text-xs font-bold text-slate-400 block mb-1">Brand Name</label>
                  <input type="text" value={editingBrand.name} onChange={(e) => setEditingBrand({...editingBrand, name: e.target.value})} className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-sm text-white focus:border-slate-500 outline-none"/>
                </div>
                <div>
                  <label className="text-xs font-bold text-slate-400 block mb-1">Category</label>
                  <select value={editingBrand.category} onChange={(e) => setEditingBrand({...editingBrand, category: e.target.value})} className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-sm text-white focus:border-slate-500 outline-none">
                    <option value="gaming">Gaming</option>
                    <option value="retail">Retail</option>
                    <option value="entertainment">Entertainment</option>
                    <option value="utility">Utility</option>
                    <option value="other">Other</option>
                  </select>
                </div>
                <div className="md:col-span-2 space-y-2">
                  <div className="flex justify-between items-center">
                    <label className="text-xs font-bold text-slate-400">Brand Image/Logo</label>
                    {editingBrand.imageUrl && (
                      <button
                        type="button"
                        onClick={() => setEditingBrand({ ...editingBrand, imageUrl: "" })}
                        className="text-xs font-bold text-rose-500 hover:text-rose-400 flex items-center gap-1 transition cursor-pointer"
                      >
                        <Trash2 size={12} /> Remove Logo
                      </button>
                    )}
                  </div>
                  
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                    {/* Upload dropzone area */}
                    <div 
                      className="sm:col-span-2 border-2 border-dashed border-slate-800 hover:border-slate-700 bg-slate-950/50 rounded-xl p-4 flex flex-col items-center justify-center text-center cursor-pointer transition relative group"
                      onDragOver={(e) => e.preventDefault()}
                      onDrop={(e) => {
                        e.preventDefault();
                        const file = e.dataTransfer.files?.[0];
                        if (file) {
                          if (file.size > 3 * 1024 * 1024) {
                            showNotification("Image is too big (Max 3MB)", "error");
                            return;
                          }
                          const r = new FileReader();
                          r.onloadend = () => {
                            if (typeof r.result === "string") {
                              setEditingBrand({ ...editingBrand, imageUrl: r.result });
                              showNotification("Logo uploaded successfully");
                            }
                          };
                          r.readAsDataURL(file);
                        }
                      }}
                      onClick={() => document.getElementById("logo-file-upload")?.click()}
                    >
                      <input 
                        id="logo-file-upload" 
                        type="file" 
                        accept="image/*" 
                        className="hidden" 
                        onChange={(e) => {
                          const file = e.target.files?.[0];
                          if (file) {
                            if (file.size > 3 * 1024 * 1024) {
                              showNotification("Image is too big (Max 3MB)", "error");
                              return;
                            }
                            const r = new FileReader();
                            r.onloadend = () => {
                              if (typeof r.result === "string") {
                                setEditingBrand({ ...editingBrand, imageUrl: r.result });
                                showNotification("Logo uploaded successfully");
                              }
                            };
                            r.readAsDataURL(file);
                          }
                        }}
                      />
                      <ImageIcon className="text-slate-500 group-hover:text-rose-500 group-hover:scale-110 mb-2 transition duration-200" size={24} />
                      <p className="text-slate-300 text-xs font-bold">Drag & drop logo here or browse</p>
                      <p className="text-[10px] text-slate-500 mt-1 font-mono">PNG, JPG, SVG up to 3MB</p>
                    </div>

                    {/* Logo Preview area */}
                    <div className="bg-slate-950 border border-slate-800 rounded-xl p-3 flex flex-col items-center justify-center min-h-[110px] relative">
                      {editingBrand.imageUrl ? (
                        <>
                          <img 
                            src={editingBrand.imageUrl} 
                            alt="Brand Logo" 
                            className="max-h-16 max-w-full rounded object-contain drop-shadow-md"
                            referrerPolicy="no-referrer"
                            onError={(e) => {
                              (e.target as HTMLImageElement).src = "https://images.unsplash.com/photo-1523474253046-8cd2748b5fd2?w=80&auto=format&fit=crop";
                            }}
                          />
                          <span className="text-[9px] text-slate-500 font-mono mt-2 truncate w-full text-center">Active Image</span>
                        </>
                      ) : (
                        <div className="text-center">
                          <div className="w-10 h-10 rounded bg-slate-900 border border-slate-800 flex items-center justify-center mx-auto text-slate-600 font-bold text-xs">NO</div>
                          <span className="text-[10px] text-slate-600 block mt-2">No Logo Selected</span>
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Manual input as compact backup option */}
                  <div className="relative pt-1">
                    <input 
                      type="text" 
                      value={editingBrand.imageUrl} 
                      onChange={(e) => setEditingBrand({...editingBrand, imageUrl: e.target.value})} 
                      placeholder="Or paste Direct Image URL here..." 
                      className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-xs text-white focus:border-slate-500 outline-none"
                    />
                  </div>
                </div>
                <div>
                  <label className="text-xs font-bold text-slate-400 block mb-1">Text Color Class (Tailwind)</label>
                  <input type="text" value={editingBrand.textColor} onChange={(e) => setEditingBrand({...editingBrand, textColor: e.target.value})} className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-sm text-white focus:border-slate-500 outline-none"/>
                </div>
                <div>
                  <label className="text-xs font-bold text-slate-400 block mb-1">Background Hex Color</label>
                  <input type="color" value={editingBrand.bgHex} onChange={(e) => setEditingBrand({...editingBrand, bgHex: e.target.value})} className="w-full h-[38px] bg-slate-950 border border-slate-800 rounded-lg p-1 cursor-pointer"/>
                </div>
              </div>

              {/* Toggles */}
              <div className="bg-slate-950 border border-slate-800 p-4 rounded-xl flex flex-wrap gap-6">
                 <label className="flex items-center gap-2 cursor-pointer">
                    <input type="checkbox" checked={editingBrand.requiresPlayerId || false} onChange={e => setEditingBrand({...editingBrand, requiresPlayerId: e.target.checked})} className="accent-rose-500 rounded" />
                    <span className="text-sm font-medium text-slate-300">Requires Target ID / UID (e.g., Gaming)</span>
                 </label>
                 <label className="flex items-center gap-2 cursor-pointer">
                    <input type="checkbox" checked={editingBrand.requiresEmail !== false} onChange={e => setEditingBrand({...editingBrand, requiresEmail: e.target.checked})} className="accent-rose-500 rounded" />
                    <span className="text-sm font-medium text-slate-300">Requires User Email ID</span>
                 </label>
              </div>

              {/* Products/Denominations */}
              <div>
                 <div className="flex justify-between items-center mb-3">
                    <h5 className="font-bold text-white text-sm">Available Products</h5>
                    <button onClick={addProductToEditingBrand} className="text-xs bg-slate-800 hover:bg-slate-700 text-slate-300 px-3 py-1 rounded-md flex items-center gap-1"><Plus size={14}/> Add Product</button>
                 </div>
                 
                 <div className="space-y-3">
                    {(!editingBrand.products || editingBrand.products.length === 0) && (
                        <div className="text-center text-xs text-slate-500 p-4 border border-dashed border-slate-700 rounded-xl">No products added. Users won't be able to purchase this brand.</div>
                    )}
                    {editingBrand.products?.map((prod, i) => (
                        <div key={i} className="bg-slate-950 border border-slate-800 p-3 rounded-xl flex flex-col md:flex-row gap-2.5 items-end relative pt-5 text-sans">
                            <button onClick={() => removeProduct(i)} className="absolute top-1 right-2 p-1 text-slate-600 hover:text-rose-500"><X size={14}/></button>
                            
                            <div className="flex-1 w-full relative">
                                <label className="text-[9px] text-slate-500 absolute -top-2 left-2 bg-slate-950 px-1 font-bold">Product Name</label>
                                <input type="text" value={prod.name || ''} onChange={e => handleProductChange(i, 'name', e.target.value)} placeholder="e.g. 380 UC Pack" className="w-full bg-transparent border border-slate-800 rounded p-2 text-xs text-white outline-none focus:border-slate-500"/>
                            </div>
                            <div className="w-full md:w-24 relative">
                                <label className="text-[9px] text-slate-500 absolute -top-2 left-2 bg-slate-950 px-1 font-bold">Reward Type</label>
                                <input type="text" value={prod.rewardType || ''} onChange={e => handleProductChange(i, 'rewardType', e.target.value)} placeholder="e.g. UC, FF Diamonds" className="w-full bg-transparent border border-slate-800 rounded p-2 text-xs text-white outline-none focus:border-slate-500"/>
                            </div>
                            <div className="w-full md:w-20 relative">
                                <label className="text-[9px] text-slate-500 absolute -top-2 left-2 bg-slate-950 px-1 font-bold">Reward Qty</label>
                                <input type="number" value={prod.rewardAmount || ''} onChange={e => handleProductChange(i, 'rewardAmount', Number(e.target.value))} placeholder="e.g. 380" className="w-full bg-transparent border border-slate-800 rounded p-2 text-xs text-white outline-none focus:border-slate-500"/>
                            </div>
                            <div className="w-full md:w-20 relative">
                                <label className="text-[9px] text-slate-500 absolute -top-2 left-2 bg-slate-950 px-1 font-bold">Orig Price</label>
                                <input type="number" value={prod.originalPrice} onChange={e => handleProductChange(i, 'originalPrice', Number(e.target.value))} className="w-full bg-transparent border border-slate-800 rounded p-2 text-xs text-white outline-none"/>
                            </div>
                            <div className="w-full md:w-20 relative">
                                <label className="text-[9px] text-slate-500 absolute -top-2 left-2 bg-slate-950 px-1 font-bold">Sell Price</label>
                                <input type="number" value={prod.sellingPrice} onChange={e => handleProductChange(i, 'sellingPrice', Number(e.target.value))} className="w-full bg-transparent border border-slate-800 rounded p-2 text-xs text-emerald-400 font-bold outline-none"/>
                            </div>
                            <div className="w-full md:w-16 relative">
                                <label className="text-[9px] text-slate-500 absolute -top-2 left-2 bg-slate-950 px-1 font-bold">Disc %</label>
                                <input readOnly type="number" value={prod.discountPercentage} className="w-full bg-transparent border border-slate-800/60 rounded p-2 text-xs text-amber-500 font-bold outline-none cursor-not-allowed" disabled/>
                            </div>
                            <div className="w-full md:w-18 relative">
                                <label className="text-[9px] text-slate-500 absolute -top-2 left-2 bg-slate-950 px-1 font-bold">Stock</label>
                                <input type="number" value={prod.stock} onChange={e => handleProductChange(i, 'stock', Number(e.target.value))} className="w-full bg-transparent border border-slate-800 rounded p-2 text-xs text-white outline-none"/>
                            </div>
                        </div>
                    ))}
                 </div>
              </div>
            </div>

            <div className="p-4 border-t border-slate-800 flex justify-end gap-3 bg-slate-950 rounded-b-2xl">
              <button onClick={() => setEditingBrand(null)} className="px-4 py-2 text-slate-400 hover:text-white font-medium text-sm">Cancel</button>
              <button onClick={handleSaveBrand} className="px-6 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-lg text-sm flex items-center gap-2"><Save size={16}/> Save Changes</button>
            </div>
          </div>
        </div>
      )}

      {loading ? (
        <div className="py-20 text-center text-xs text-slate-500 animate-pulse font-mono">Loading Brands...</div>
      ) : brands.length === 0 ? (
        <div className="py-12 border-2 border-dashed border-slate-800 rounded-2xl text-center">
            <ImageIcon className="mx-auto text-slate-700 mb-2" size={32} />
            <p className="text-sm text-slate-400 font-medium">No Brands Found</p>
            <p className="text-xs text-slate-500 mt-1">Add a new brand or click "Sync Defaults" to populate.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {brands.map(brand => (
             <div key={brand.id} className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden hover:border-slate-700 transition">
                <div className="h-24 w-full relative" style={{ backgroundColor: brand.bgHex }}>
                   <div className="absolute inset-0 p-4 flex gap-4 items-center">
                     <img src={brand.imageUrl} alt={brand.name} className="w-16 h-16 rounded-xl shadow-lg object-cover bg-white"/>
                     <div className="drop-shadow-md">
                        <h4 className="font-black text-white text-lg leading-tight">{brand.name}</h4>
                        <span className="text-[10px] uppercase font-bold text-white/70 tracking-widest">{brand.category}</span>
                     </div>
                   </div>
                </div>
                <div className="p-4 flex flex-col gap-3">
                   <div className="flex gap-2 text-[10px] text-slate-400">
                     {brand.requiresPlayerId && <span className="bg-rose-500/10 text-rose-400 px-2 py-1 rounded border border-rose-500/20">UID Req</span>}
                     {brand.requiresEmail !== false && <span className="bg-slate-800 text-slate-300 px-2 py-1 rounded border border-slate-700">Email Req</span>}
                   </div>
                   <div className="text-xs text-slate-300">
                     <span className="font-bold text-slate-400">Products: </span>
                     {brand.products?.length || brand.popularDenominations?.length || 0} items available
                   </div>
                   <div className="flex gap-2 pt-2 border-t border-slate-800 mt-1">
                      <button onClick={() => setEditingBrand(brand)} className="flex-1 bg-slate-800 hover:bg-slate-700 text-white py-2 rounded-lg text-xs font-bold flex items-center justify-center gap-2"><Edit2 size={14}/> Edit Info</button>
                      <button onClick={() => setDeleteConfirmId(brand.id)} className="bg-rose-950/30 hover:bg-rose-900/50 text-rose-500 p-2 rounded-lg cursor-pointer"><Trash2 size={16}/></button>
                       {deleteConfirmId === brand.id && (
                         <div className="flex gap-1.5 items-center bg-rose-950/50 border border-rose-900/40 p-1.5 rounded-lg ml-1">
                           <button 
                             onClick={() => handleDeleteBrand(brand.id)} 
                             className="bg-rose-600 hover:bg-rose-500 text-white text-[10px] font-bold px-2 py-1 rounded cursor-pointer whitespace-nowrap animate-pulse"
                           >
                             Confirm Delete?
                           </button>
                           <button 
                             onClick={() => setDeleteConfirmId(null)} 
                             className="text-slate-400 hover:text-white text-[11px] px-1 font-extrabold cursor-pointer"
                           >
                             X
                           </button>
                         </div>
                       )}
                   </div>
                </div>
             </div>
          ))}
        </div>
      )}
    </div>
  );
}
