import React, { useState } from "react";
import { UserProfile } from "../types";
import { MessageCircle, HelpCircle, FileText, Send } from "lucide-react";

interface SupportTabProps {
  userProfile: UserProfile;
}

export default function SupportTab({ userProfile }: SupportTabProps) {
  const [subject, setSubject] = useState("");
  const [description, setDescription] = useState("");

  const handleSupportWhatsApp = (e: React.FormEvent) => {
    e.preventDefault();
    if (!subject || !description) return;

    const whatsappText = `Hello Support,
I need help regarding an issue.

*UID:* ${userProfile.id}
*Name:* ${userProfile.name}

*Subject:* ${subject}
*Description:* ${description}`;

    const whatsappOrderLink = `https://wa.me/4915510539752?text=${encodeURIComponent(whatsappText)}`;
    window.open(whatsappOrderLink, "_blank");
  };

  return (
    <div className="max-w-2xl mx-auto space-y-6 animate-fade-in">
      <div className="bg-emerald-50 dark:bg-emerald-950/30 border border-emerald-100 dark:border-emerald-900/40 p-6 rounded-3xl flex flex-col items-start gap-4 shadow-sm text-emerald-800 dark:text-emerald-300 relative overflow-hidden">
        <div className="flex flex-col md:flex-row items-center gap-4 relative z-10 w-full text-center md:text-left">
          <div className="w-16 h-16 bg-emerald-100 dark:bg-emerald-900/50 rounded-2xl flex items-center justify-center shrink-0 mx-auto md:mx-0">
            <MessageCircle size={32} className="text-emerald-600 dark:text-emerald-400" />
          </div>
          <div className="flex-grow">
            <h2 className="text-xl font-bold mb-1">Customer Support</h2>
            <p className="text-xs opacity-90 leading-relaxed mb-4 md:mb-0 max-w-sm mx-auto md:mx-0">
              We are here to help! Connect directly on our official WhatsApp support channel. Our agents will assist you instantly.
            </p>
          </div>
          <button
            onClick={() => {
              const whatsappText = `Hello Support, I need help.\n\n*UID:* ${userProfile.id}\n*Name:* ${userProfile.name}`;
              window.open(`https://wa.me/4915510539752?text=${encodeURIComponent(whatsappText)}`, "_blank");
            }}
            className="w-full md:w-auto shrink-0 bg-emerald-600 hover:bg-emerald-500 text-white font-bold py-3 px-6 rounded-2xl text-sm flex items-center justify-center gap-2 cursor-pointer transition-colors shadow-sm"
          >
            <MessageCircle size={18} fill="currentColor" />
            <span>Chat on WhatsApp</span>
          </button>
        </div>
      </div>

      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-6 rounded-3xl shadow-sm">
        <h3 className="font-bold text-slate-800 dark:text-slate-100 flex items-center gap-2 mb-4">
          <HelpCircle size={18} className="text-rose-500" />
          <span>Submit a Support Ticket</span>
        </h3>
        
        <form onSubmit={handleSupportWhatsApp} className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="text-xs font-bold text-slate-500 block mb-1">Your UID:</label>
              <input type="text" readOnly value={userProfile.id} className="w-full p-3 bg-slate-100 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl text-sm font-mono text-slate-500 outline-none cursor-not-allowed" />
            </div>
            <div>
              <label className="text-xs font-bold text-slate-500 block mb-1">Your Name:</label>
              <input type="text" readOnly value={userProfile.name} className="w-full p-3 bg-slate-100 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl text-sm font-mono text-slate-500 outline-none cursor-not-allowed" />
            </div>
          </div>

          <div>
            <label className="text-xs font-bold text-slate-500 block mb-1">Subject / Reason:</label>
            <select
              required
              value={subject}
              onChange={(e) => setSubject(e.target.value)}
              className="w-full p-3 bg-slate-50 border border-slate-200 dark:bg-slate-950 dark:border-slate-800 rounded-xl text-sm outline-none focus:border-slate-400"
            >
              <option value="" disabled>Select a reason...</option>
              <option value="Payment Deducted but not Verified">Payment Deducted but not Verified</option>
              <option value="Coupon Code not Working">Coupon Code not Working</option>
              <option value="Want to change Email Delivery">Want to change Email Delivery</option>
              <option value="Other">Other Issues</option>
            </select>
          </div>

          <div>
            <label className="text-xs font-bold text-slate-500 block mb-1">Description / Details:</label>
            <textarea
              required
              rows={4}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Please describe your issue in detail..."
              className="w-full p-3 bg-slate-50 border border-slate-200 dark:bg-slate-950 dark:border-slate-800 rounded-xl text-sm outline-none focus:border-slate-400 resize-none"
            />
          </div>

          <div className="pt-2">
            <button
              type="submit"
              className="w-full bg-emerald-600 hover:bg-emerald-500 text-white font-bold py-3.5 px-4 rounded-xl text-sm flex items-center justify-center gap-2 cursor-pointer transition-colors shadow-sm"
            >
              <span>Connect on WhatsApp</span>
              <Send size={16} />
            </button>
          </div>
        </form>
      </div>

      <div className="bg-slate-50 dark:bg-slate-800/30 p-4 rounded-2xl border border-slate-100 dark:border-slate-800 text-xs text-slate-500 dark:text-slate-400 flex items-start gap-2">
        <FileText size={16} className="shrink-0 mt-0.5" />
        <p>Please note: Our support team operates during active business hours. Be prepared to share your UTR or screenshots of payment on WhatsApp if asked by our representatives.</p>
      </div>
    </div>
  );
}
