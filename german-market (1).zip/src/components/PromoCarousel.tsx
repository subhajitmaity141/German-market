import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Clock, ShieldCheck, Image as ImageIcon } from "lucide-react";
import { collection, onSnapshot } from "firebase/firestore";
import { db, handleFirestoreError, OperationType } from "../firebase";
import { PromoBanner } from "../types";

export default function PromoCarousel() {
  const [banners, setBanners] = useState<PromoBanner[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const bannersCol = collection(db, "banners");
    const unsubscribe = onSnapshot(bannersCol, (snapshot) => {
      const list: PromoBanner[] = [];
      snapshot.forEach((doc) => {
        list.push(doc.data() as PromoBanner);
      });
      list.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
      setBanners(list);
      setLoading(false);
    }, (err) => {
      console.error("Failed to fetch custom banners:", err);
      setLoading(false);
      handleFirestoreError(err, OperationType.LIST, "banners");
    });

    return () => unsubscribe();
  }, []);

  const hasCustomBanners = banners.length > 0;
  const slidesCount = hasCustomBanners ? banners.length : 3;

  useEffect(() => {
    if (slidesCount <= 1) return;
    const timer = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % slidesCount);
    }, 6000);
    return () => clearInterval(timer);
  }, [slidesCount]);

  useEffect(() => {
    if (currentIndex >= slidesCount) {
      setCurrentIndex(0);
    }
  }, [slidesCount, currentIndex]);

  return (
    <div className="relative w-full h-48 sm:h-44 rounded-3xl overflow-hidden group">
      <AnimatePresence mode="wait">
        {hasCustomBanners ? (
          banners.map((banner, index) => {
            if (index !== currentIndex) return null;
            
            const bgStyle = banner.imageUrl.startsWith("data:") 
              ? { backgroundImage: `linear-gradient(to right, rgba(15,23,42,0.95), rgba(15,23,42,0.55)), url(${banner.imageUrl})` }
              : { backgroundImage: `linear-gradient(to right, rgba(15,23,42,0.95), rgba(15,23,42,0.6)), url(${banner.imageUrl})` };

            return (
              <motion.div
                key={banner.id}
                initial={{ opacity: 0, x: 50 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -50 }}
                transition={{ duration: 0.4 }}
                className="absolute inset-0 bg-slate-900 bg-cover bg-center text-white flex items-center shadow-lg border border-slate-800"
                style={bgStyle}
              >
                {/* Visual Glow highlights */}
                <div className="absolute top-0 right-0 -mr-20 -mt-20 w-64 h-64 bg-rose-500/10 blur-3xl rounded-full mix-blend-screen pointer-events-none"></div>
                <div className="absolute bottom-0 left-0 -ml-20 -mb-20 w-64 h-64 bg-amber-500/10 blur-3xl rounded-full mix-blend-screen pointer-events-none"></div>
                
                <div className="relative z-10 w-full p-6 md:px-10 flex flex-col justify-center h-full">
                  {banner.badge && (
                    <div className="bg-gradient-to-r from-rose-500 to-rose-600 text-white text-[10px] font-black px-3 py-1 rounded-sm max-w-max uppercase tracking-widest mb-2.5 shadow-md">
                      {banner.badge}
                    </div>
                  )}
                  <h2 className="text-xl md:text-2xl font-black tracking-tight max-w-[480px] leading-tight mb-2 drop-shadow-sm">
                    {banner.title}
                  </h2>
                  <div className="text-xs md:text-sm font-medium text-slate-300 max-w-[420px] leading-relaxed">
                    {banner.subtitle}
                  </div>
                </div>
              </motion.div>
            );
          })
        ) : (
          // Dynamic slider fallback to legacy styled static panels
          <>
            {currentIndex === 0 && (
              <motion.div
                key="banner1"
                initial={{ opacity: 0, x: 50 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -50 }}
                transition={{ duration: 0.4 }}
                className="absolute inset-0 bg-gradient-to-r from-slate-900 via-slate-800 to-slate-900 overflow-hidden text-white flex items-center shadow-lg"
              >
                <div className="absolute top-0 right-0 -mr-20 -mt-20 w-64 h-64 bg-amber-500/20 blur-3xl rounded-full mix-blend-screen pointer-events-none"></div>
                <div className="absolute bottom-0 left-0 -ml-20 -mb-20 w-64 h-64 bg-rose-500/20 blur-3xl rounded-full mix-blend-screen pointer-events-none"></div>
                
                <div className="absolute right-0 bottom-0 opacity-10 font-black text-[150px] leading-none select-none -mb-8 -mr-8 italic text-amber-500">
                  50%
                </div>
                
                <div className="relative z-10 w-full p-6 md:px-10 flex flex-col justify-center h-full">
                  <div className="bg-gradient-to-r from-amber-400 to-amber-600 text-slate-900 text-[10px] font-black px-3 py-1 rounded-sm max-w-max uppercase tracking-widest mb-3 shadow-md">
                    Limited Time Offer
                  </div>
                  <h2 className="text-2xl md:text-3xl font-black tracking-tight max-w-[320px] leading-tight mb-2 drop-shadow-sm">
                    Get All Codes at Flat <span className="text-amber-400">50% Rate</span>
                  </h2>
                  <div className="text-xs md:text-sm font-medium text-slate-300 max-w-[280px]">
                    Securely checkout using any UPI app and save big on top brands.
                  </div>
                </div>
              </motion.div>
            )}

            {currentIndex === 1 && (
              <motion.div
                key="banner2"
                initial={{ opacity: 0, x: 50 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -50 }}
                transition={{ duration: 0.4 }}
                className="absolute inset-0 bg-slate-900 border border-slate-800 text-white p-6 md:px-8 flex items-center"
              >
                <div className="flex items-start gap-4">
                  <div className="w-14 h-14 bg-rose-500/10 rounded-2xl flex items-center justify-center shrink-0 border border-rose-500/20 shadow-inner">
                    <Clock size={28} className="text-rose-500 animate-pulse" />
                  </div>
                  <div>
                    <div className="text-rose-400 text-[10px] font-bold uppercase tracking-wider mb-1">
                      Flash Delivery
                    </div>
                    <h2 className="text-xl font-extrabold tracking-tight leading-tight mb-1">
                      2 to 10 minutes
                    </h2>
                    <p className="text-xs text-slate-400 max-w-sm">
                      Guaranteed confirmation delivery directly to your registered deliver email. Verified by admin checks in real-time.
                    </p>
                  </div>
                </div>
              </motion.div>
            )}

            {currentIndex === 2 && (
              <motion.div
                key="banner3"
                initial={{ opacity: 0, x: 50 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -50 }}
                transition={{ duration: 0.4 }}
                className="absolute inset-0 bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-slate-800 dark:text-slate-100 p-6 md:px-8 flex items-center"
              >
                <div className="flex items-start gap-4">
                  <div className="w-14 h-14 bg-emerald-50 dark:bg-emerald-950/40 rounded-2xl flex items-center justify-center shrink-0 border border-emerald-100 dark:border-emerald-900/30">
                    <ShieldCheck size={28} className="text-emerald-600 dark:text-emerald-400" />
                  </div>
                  <div>
                    <div className="text-emerald-600 dark:text-emerald-400 text-[10px] font-bold uppercase tracking-wider mb-1">
                      Verified Checkout
                    </div>
                    <h2 className="text-xl font-extrabold tracking-tight leading-tight mb-1">
                      Global UTR Security Lock
                    </h2>
                    <p className="text-[11px] text-slate-500 dark:text-slate-400 max-w-md leading-relaxed hidden sm:block mb-1">
                      Every UPI receipt transaction is audited. One UTR can only be submitted once to guarantee structural integrity of orders database.
                    </p>
                    <p className="text-[10px] text-slate-500 dark:text-slate-500 max-w-md leading-relaxed sm:hidden mb-1 border-emerald-500">
                      One UTR can only be submitted once for safe queue delivery.
                    </p>
                    <p className="text-[10px] font-mono text-emerald-600 dark:text-emerald-500 font-bold bg-emerald-50/50 dark:bg-emerald-950/20 px-2 py-0.5 rounded-max inline-block">
                      Gateway payee: h4xvivekyu1309@fam
                    </p>
                  </div>
                </div>
              </motion.div>
            )}
          </>
        )}
      </AnimatePresence>

      {/* Carousel Indicators */}
      {slidesCount > 1 && (
        <div className="absolute bottom-3 left-0 right-0 flex justify-center gap-1.5 z-20">
          {Array.from({ length: slidesCount }).map((_, i) => (
            <button
              key={i}
              onClick={() => setCurrentIndex(i)}
              className={`h-1.5 rounded-full transition-all duration-300 ${
                currentIndex === i ? "w-6 bg-rose-500" : "w-1.5 bg-slate-300/50 dark:bg-slate-700/50 cursor-pointer hover:bg-slate-400 dark:hover:bg-slate-600"
              }`}
              aria-label={`Go to slide ${i + 1}`}
            />
          ))}
        </div>
      )}
    </div>
  );
}
