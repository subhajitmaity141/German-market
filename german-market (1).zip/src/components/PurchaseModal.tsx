import React, { useState } from "react";
import { Brand, UserProfile, Order } from "../types";
import { doc, getDoc, setDoc } from "firebase/firestore";
import { db, handleFirestoreError, OperationType } from "../firebase";
import { 
  X, Check, Mail, ChevronRight, ArrowLeft, Download, ExternalLink, 
  Clock, AlertCircle, ShieldCheck, CreditCard, Copy 
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

interface PurchaseModalProps {
  brand: Brand;
  user: UserProfile;
  initialAmount?: number | null;
  onClose: () => void;
  onOrderPlaced: (orderId: string) => void;
}

export default function PurchaseModal({ brand, user, initialAmount, onClose, onOrderPlaced }: PurchaseModalProps) {
  const [step, setStep] = useState<1 | 2 | 3 | 4>(1);
  
  // Form Values
  const [selectedProduct, setSelectedProduct] = useState<any>(brand.products && brand.products.length > 0 ? brand.products[0] : null);
  const [faceValue, setFaceValue] = useState<number>(initialAmount || (selectedProduct ? selectedProduct.originalPrice : (brand.popularDenominations?.[1] || brand.popularDenominations?.[0] || 0)));
  const [deliveryEmail, setDeliveryEmail] = useState<string>(user.email || "");
  const [playerId, setPlayerId] = useState<string>("");
  const [utr, setUtr] = useState<string>("");
  
  // Statuses
  const [submitting, setSubmitting] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [successOrderId, setSuccessOrderId] = useState<string | null>(null);

  // Calculations
  const discountedAmount = selectedProduct ? selectedProduct.sellingPrice : Math.round(faceValue * 0.5); // 50% discount rate

  // Custom UPI Link construction target
  // pa: Payee Address, pn: Payee Name, am: Amount, cu: Currency, tn: Transaction Note
  const upiLink = `upi://pay?pa=h4xvivekyu1309@fam&pn=German%20Market&am=${discountedAmount}&cu=INR&tn=Order%20for%2520${encodeURIComponent(brand.name)}`;
  
  // QR code API image string
  const qrCodeUrl = `https://api.qrserver.com/v1/create-qr-code/?size=300x300&color=0f172a&data=${encodeURIComponent(upiLink)}`;

  // Step 1: Validate Form
  const handleNextToPayment = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    if (brand.requiresEmail !== false) {
      if (!deliveryEmail || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(deliveryEmail)) {
        setErrorMsg("Please enter a valid delivery email address.");
        return;
      }
    }
    if (brand.requiresPlayerId) {
      if (!playerId || playerId.trim() === "") {
        setErrorMsg("Player / User ID is required for this brand.");
        return;
      }
    }
    setStep(2);
  };

  // Download QR code utility
  const handleDownloadQR = async () => {
    try {
      // Create offscreen image
      const img = new Image();
      img.crossOrigin = "anonymous";
      img.src = qrCodeUrl;
      img.onload = () => {
        // Draw to canvas for native local JPEG format
        const canvas = document.createElement("canvas");
        canvas.width = 300;
        canvas.height = 360;
        const ctx = canvas.getContext("2d");
        if (ctx) {
          // Fill white background
          ctx.fillStyle = "#ffffff";
          ctx.fillRect(0, 0, 300, 360);
          
          // Draw QR
          ctx.drawImage(img, 0, 0, 300, 300);
          
          // Draw details footer text
          ctx.fillStyle = "#e11d48"; // Rose-600 color
          ctx.font = "bold 14px sans-serif";
          ctx.textAlign = "center";
          ctx.fillText(`GERMAN MARKET: ₹${discountedAmount}`, 150, 315);
          
          ctx.fillStyle = "#475569"; // Slate-600
          ctx.font = "11px sans-serif";
          ctx.fillText(`Pay to: h4xvivekyu1309@fam`, 150, 335);

          // Trigger download anchor
          const link = document.createElement("a");
          link.download = `GermanMarket_${brand.id}_₹${discountedAmount}.jpg`;
          link.href = canvas.toDataURL("image/jpeg", 0.9);
          link.click();
        }
      };
    } catch (err) {
      alert("Failed to download QR image. Please take a screenshot instead.");
    }
  };

  // Step 3: Handle Payment Submission with UTR uniqueness guard
  const handleUtrSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const sanitizedUtr = utr.trim().replace(/\s/g, "");
    
    // Quick validation
    if (!sanitizedUtr || sanitizedUtr.length < 6) {
      setErrorMsg("Please enter a valid Transaction ID / UTR number.");
      return;
    }

    setSubmitting(true);
    setErrorMsg(null);

    try {
      // 1. UNIQUE TRANSACTION CHECK
      // Check if UTR document already exists to prevent double spend
      const utrRef = doc(db, "used_utrs", sanitizedUtr);
      const utrSnap = await getDoc(utrRef);

      if (utrSnap.exists()) {
        setErrorMsg("This Transaction ID / UTR has already been submitted for another order! Duplications are strictly locked.");
        setSubmitting(false);
        return;
      }

      // Generate 10-digit tracking order ID
      const newOrderId = Math.floor(1000000000 + Math.random() * 9000000000).toString();

      // Get device tracking info from App state or generate fallbacks
      const deviceFingerprint = user.deviceInfo || `${navigator.userAgent} | ${window.screen.width}x${window.screen.height}`;

      // 2. Lock UTR in used_utrs database atomically
      await setDoc(utrRef, {
        utr: sanitizedUtr,
        orderId: newOrderId,
        createdAt: new Date().toISOString()
      });

      // 3. Create active Order document
      const newOrder: Order = {
        id: newOrderId,
        userEmailOrId: user.id,
        email: brand.requiresEmail !== false ? deliveryEmail : "N/A",
        playerId: brand.requiresPlayerId ? playerId : null,
        deviceInfo: deviceFingerprint,
        brand: brand.name,
        faceValue,
        paidAmount: discountedAmount,
        utr: sanitizedUtr,
        status: "Pending",
        createdAt: new Date().toISOString(),
        rewardType: selectedProduct?.rewardType || (brand.id === "bgmi" ? "UC" : (brand.id === "freefire" ? "Diamonds" : "")),
        rewardAmount: selectedProduct?.rewardAmount || (brand.id === "bgmi" ? Math.round(faceValue * 0.8) : (brand.id === "freefire" ? Math.round(faceValue * 1.25) : faceValue))
      };

      await setDoc(doc(db, "orders", newOrderId), newOrder);
      
      setSuccessOrderId(newOrderId);
      setStep(4);
    } catch (err) {
      try {
        handleFirestoreError(err, OperationType.CREATE, "orders");
      } catch (e: any) {
        setErrorMsg("Submission error: " + e.message);
      }
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm overflow-y-auto">
      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: 10 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, y: 10 }}
        className="bg-white dark:bg-slate-900 rounded-3xl w-full max-w-md overflow-hidden relative shadow-2xl border border-slate-100 dark:border-slate-800"
      >
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 transition-colors p-1 bg-slate-100 dark:bg-slate-800 rounded-full cursor-pointer"
        >
          <X size={16} />
        </button>

        {/* Modal Header */}
        <div className="p-6 pb-4 border-b border-slate-100 dark:border-slate-800 bg-slate-50 dark:bg-slate-900/50">
          <div className="flex items-center gap-3">
            <span className="w-10 h-10 rounded-2xl flex items-center justify-center font-bold text-white shadow-md text-sm uppercase" style={{ backgroundColor: brand.bgHex }}>
              {brand.name[0]}
            </span>
            <div>
              <span className="text-[10px] bg-rose-100 dark:bg-rose-950/40 text-rose-600 dark:text-rose-400 font-extrabold px-2 py-0.5 rounded-full inline-block">
                50% OFF RATE
              </span>
              <h3 className="font-bold text-slate-900 dark:text-slate-100 text-base mt-0.5">
                {brand.name}
              </h3>
            </div>
          </div>
        </div>

        {/* Dynamic Step Content */}
        <div className="p-6">
          {errorMsg && (
            <div className="mb-4 bg-rose-50 dark:bg-rose-950/20 text-rose-600 dark:text-rose-400 p-3.5 rounded-xl text-xs flex gap-2 border border-rose-100 dark:border-rose-900/30">
              <AlertCircle size={15} className="shrink-0 mt-0.5" />
              <span>{errorMsg}</span>
            </div>
          )}

          <AnimatePresence mode="wait">
            {/* STEP 1: Select Promos & Input delivery details */}
            {step === 1 && (
              <motion.div
                key="step-1"
                initial={{ opacity: 0, x: -15 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 15 }}
              >
                <form onSubmit={handleNextToPayment} className="space-y-5">
                  <div>
                    <label className="text-xs font-bold text-slate-700 dark:text-slate-300 block mb-2 uppercase tracking-wide">
                      Select Value / Product:
                    </label>
                    <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                      {brand.products && brand.products.length > 0 ? (
                        brand.products.map((prod) => (
                          <button
                            key={prod.id}
                            type="button"
                            onClick={() => {
                                setFaceValue(prod.originalPrice);
                                setSelectedProduct(prod);
                            }}
                            className={`py-3 px-2 rounded-xl text-xs font-bold border transition-all cursor-pointer flex flex-col items-center gap-1 ${
                              selectedProduct?.id === prod.id
                                ? "bg-rose-600 border-rose-600 text-white shadow-md shadow-rose-600/10"
                                : "bg-white border-slate-200 text-slate-800 hover:border-slate-300 dark:bg-slate-950 dark:border-slate-800 dark:text-slate-200"
                            }`}
                          >
                            <span className="truncate w-full text-center">{prod.name || `₹${prod.originalPrice}`}</span>
                            {prod.rewardType && prod.rewardAmount ? (
                              <span className={`text-[10px] font-bold ${selectedProduct?.id === prod.id ? 'text-rose-200' : 'text-rose-500'}`}>
                                {prod.rewardAmount} {prod.rewardType}
                              </span>
                            ) : null}
                            <span className={`text-[10px] font-mono ${selectedProduct?.id === prod.id ? 'text-rose-100' : 'text-emerald-500'}`}>₹{prod.sellingPrice}</span>
                          </button>
                        ))
                      ) : (
                        brand.popularDenominations?.map((val) => (
                          <button
                            key={val}
                            type="button"
                            onClick={() => {
                                setFaceValue(val);
                                setSelectedProduct(null);
                            }}
                            className={`py-3 px-1 rounded-xl text-xs font-mono font-bold border transition-all cursor-pointer flex flex-col items-center gap-0.5 ${
                              faceValue === val && !selectedProduct
                                ? "bg-rose-600 border-rose-600 text-white shadow-md shadow-rose-600/10"
                                : "bg-white border-slate-200 text-slate-800 hover:border-slate-300 dark:bg-slate-950 dark:border-slate-800 dark:text-slate-200"
                            }`}
                          >
                            <span>₹{val}</span>
                            {(brand.id === "bgmi" || brand.id === "freefire") && (
                              <span className={`text-[9px] font-bold ${faceValue === val ? 'text-rose-100' : 'text-rose-500'}`}>
                                {brand.id === "bgmi" ? `${Math.round(val * 0.8)} UC` : `${Math.round(val * 1.25)} DM`}
                              </span>
                            )}
                          </button>
                        ))
                      )}
                    </div>
                  </div>

                  {/* Calculations Pricing Breakdown Card */}
                  <div className="bg-slate-50 dark:bg-slate-950 p-4 rounded-2xl border border-slate-100 dark:border-slate-800 space-y-2.5">
                    {(selectedProduct?.rewardType && selectedProduct?.rewardAmount) ? (
                      <div className="flex justify-between text-xs font-bold text-slate-700 dark:text-slate-300">
                        <span>Delivery Reward Content:</span>
                        <span className="font-semibold text-rose-600 dark:text-rose-400 bg-rose-50 dark:bg-rose-950/20 px-2.5 py-0.5 rounded-lg border border-rose-100/30">
                          {selectedProduct.rewardAmount} {selectedProduct.rewardType}
                        </span>
                      </div>
                    ) : (brand.id === "bgmi" || brand.id === "freefire") ? (
                      <div className="flex justify-between text-xs font-bold text-slate-700 dark:text-slate-300">
                        <span>Delivery Reward Content:</span>
                        <span className="font-semibold text-rose-600 dark:text-rose-400 bg-rose-50 dark:bg-rose-950/20 px-2.5 py-0.5 rounded-lg border border-rose-100/30">
                          {brand.id === "bgmi" ? `${Math.round(faceValue * 0.8)} UC` : `${Math.round(faceValue * 1.25)} Diamonds`}
                        </span>
                      </div>
                    ) : null}
                    <div className="flex justify-between text-xs text-slate-500 dark:text-slate-400">
                      <span>Face Value:</span>
                      <span className="font-mono">₹{faceValue}</span>
                    </div>
                    <div className="flex justify-between text-xs text-slate-500 dark:text-slate-400">
                      <span>German Market discount rate:</span>
                      <span className="text-emerald-500 font-semibold">
                        -{selectedProduct ? Math.round((1 - selectedProduct.sellingPrice / selectedProduct.originalPrice) * 100) : 50}% Off
                      </span>
                    </div>
                    <div className="border-t border-slate-200 dark:border-slate-800/80 pt-2 flex justify-between text-sm font-bold text-slate-800 dark:text-slate-100">
                      <span>You Pay amount:</span>
                      <span className="font-mono text-rose-600 text-base">₹{discountedAmount}</span>
                    </div>
                  </div>

                  {/* Delivery Email input field */}
                  {brand.requiresEmail !== false && (
                  <div>
                    <label className="text-xs font-bold text-slate-700 dark:text-slate-300 block mb-2 uppercase tracking-wide">
                      Enter delivery Email ID:
                    </label>
                    <div className="relative">
                      <Mail className="absolute left-3.5 top-3.5 text-slate-400" size={16} />
                      <input
                        type="email"
                        required
                        placeholder="e.g. your-email@example.com"
                        value={deliveryEmail}
                        onChange={(e) => setDeliveryEmail(e.target.value)}
                        className="w-full pl-10 pr-4 py-3 bg-slate-50 border border-slate-200 dark:bg-slate-950 dark:border-slate-800 dark:text-slate-50 rounded-xl text-xs sm:text-sm focus:outline-none focus:bg-white focus:border-slate-400 transition-colors"
                      />
                    </div>
                    <p className="text-[11px] text-slate-400 mt-1.5 flex items-start gap-1">
                      <Clock size={11} className="shrink-0 mt-0.5" />
                      <span>Deliver within 2 to 10 working minute on your registered email ID.</span>
                    </p>
                  </div>
                  )}

                  {/* Player ID Field (Gaming Brands) */}
                  {brand.requiresPlayerId && (
                    <div className="">
                      <label className="text-xs font-bold text-rose-600 dark:text-rose-400 block mb-2 uppercase tracking-wide">
                        Enter Player ID / UID:
                      </label>
                      <input
                        type="text"
                        required
                        placeholder="e.g. 51234850"
                        value={playerId}
                        onChange={(e) => setPlayerId(e.target.value)}
                        className="w-full px-4 py-3 bg-rose-50/50 border border-rose-200 dark:bg-rose-950/20 dark:border-rose-900/50 dark:text-slate-50 rounded-xl text-xs sm:text-sm focus:outline-none focus:border-rose-400 transition-colors"
                      />
                      <p className="text-[10px] text-rose-500/80 mt-1 pl-1">Target UID required for game top-up.</p>
                    </div>
                  )}

                  <button
                    type="submit"
                    className="w-full bg-slate-900 border border-transparent hover:bg-slate-800 dark:bg-slate-800 dark:hover:bg-slate-700 text-white font-bold py-3.5 px-4 rounded-xl text-sm flex items-center justify-center gap-2 cursor-pointer transition-colors"
                  >
                    <span>Proceed to UPI Pay</span>
                    <ChevronRight size={14} />
                  </button>
                </form>
              </motion.div>
            )}

            {/* STEP 2: Payment dynamic QR and Pay instructions */}
            {step === 2 && (
              <motion.div
                key="step-2"
                initial={{ opacity: 0, x: 15 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -15 }}
                className="space-y-5 text-center"
              >
                {/* QR Screen Header */}
                <div className="text-left pb-1">
                  <button onClick={() => setStep(1)} className="text-xs text-rose-600 hover:text-rose-500 flex items-center gap-1 font-bold cursor-pointer">
                    <ArrowLeft size={12} />
                    <span>Back to adjust details</span>
                  </button>
                </div>

                <div className="bg-slate-50 dark:bg-slate-950 border border-slate-200/60 dark:border-slate-800/80 rounded-2xl p-4 inline-block shadow-inner">
                  <div className="text-xs text-slate-500 block mb-1 font-sans">Scan with any UPI App (GPay/PhonePay/Paytm)</div>
                  <img
                    src={qrCodeUrl}
                    alt={`UPI QR ₹${discountedAmount}`}
                    className="w-48 h-48 mx-auto rounded-lg shadow border border-white"
                  />
                  <div className="text-xs font-bold text-slate-800 dark:text-slate-100 mt-2 font-mono text-center">
                    Pay Amount: <span className="text-rose-600 text-base font-black">₹{discountedAmount}</span>
                  </div>
                </div>

                {/* Pay and Download actions */}
                <div className="grid grid-cols-2 gap-3">
                  {/* Download QR image */}
                  <button
                    onClick={handleDownloadQR}
                    className="flex items-center justify-center gap-1.5 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-800 dark:text-white py-3 px-3 rounded-xl text-xs font-bold transition-all cursor-pointer border border-slate-200/50 dark:border-slate-800"
                  >
                    <Download size={14} className="stroke-[2.5]" />
                    <span>Download QR</span>
                  </button>

                  {/* Deep link redirect payment */}
                  <a
                    href={upiLink}
                    className="flex items-center justify-center gap-1.5 bg-rose-600 hover:bg-rose-500 text-white py-3 px-3 rounded-xl text-xs font-bold transition-all cursor-pointer box-border"
                  >
                    <ExternalLink size={14} className="stroke-[2.5]" />
                    <span>Pay directly</span>
                  </a>
                </div>

                <div className="text-xs text-slate-500 leading-relaxed max-w-[340px] mx-auto bg-slate-50 dark:bg-slate-950 p-3 rounded-xl border border-slate-100 dark:border-slate-800 text-left flex flex-col gap-2">
                  <div className="flex gap-1.5 align-top">
                    <CreditCard size={15} className="text-slate-400 shrink-0 mt-0.5" />
                    <span>
                      When you click <strong>Pay directly</strong>, all compatible UPI apps on your Android/iOS device will open instantly.
                    </span>
                  </div>
                  <div className="flex items-center justify-between bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-2 rounded-lg">
                    <div className="flex flex-col">
                      <span className="text-[10px] uppercase font-bold text-slate-400">Secure Upi Payee</span>
                      <span className="font-mono text-slate-800 dark:text-slate-200">h4xvivekyu1309@fam</span>
                    </div>
                    <button
                      onClick={() => {
                        navigator.clipboard.writeText("h4xvivekyu1309@fam");
                        alert("UPI ID Copied!");
                      }}
                      className="shrink-0 flex items-center gap-1 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 font-bold px-2 py-1.5 rounded transition-colors"
                    >
                      <Copy size={12} />
                      <span className="text-[10px]">Copy</span>
                    </button>
                  </div>
                </div>

                <button
                  onClick={() => setStep(3)}
                  className="w-full bg-slate-950 hover:bg-slate-800 dark:bg-slate-800 dark:hover:bg-slate-700 text-white font-bold py-3.5 px-4 rounded-xl text-sm flex items-center justify-center gap-1.5 cursor-pointer transition-colors"
                >
                  <span>I have paid, Proceed</span>
                  <ChevronRight size={14} />
                </button>
              </motion.div>
            )}

            {/* STEP 3: Enter UPI Transaction / UTR ID */}
            {step === 3 && (
              <motion.div
                key="step-3"
                initial={{ opacity: 0, x: 15 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -15 }}
              >
                <form onSubmit={handleUtrSubmit} className="space-y-4">
                  <div className="text-left pb-1">
                    <button type="button" onClick={() => setStep(2)} className="text-xs text-rose-600 hover:text-rose-500 flex items-center gap-1 font-bold cursor-pointer">
                      <ArrowLeft size={12} />
                      <span>Back to QR details</span>
                    </button>
                  </div>

                  <div className="space-y-2">
                    <label className="text-xs font-bold text-slate-700 dark:text-slate-300 block uppercase tracking-wide">
                      Submit UTR / Transaction ID:
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="Enter 12-digit UPI UTR"
                      value={utr}
                      onChange={(e) => setUtr(e.target.value.replace(/[^a-zA-Z0-9]/g, ""))}
                      className="w-full p-4 bg-slate-50 border border-slate-200 dark:bg-slate-950 dark:border-slate-800 dark:text-slate-50 rounded-xl text-sm font-mono text-center tracking-widest focus:outline-none focus:bg-white focus:border-slate-400 uppercase"
                    />
                    <p className="text-[10px] text-slate-400 leading-relaxed font-sans mt-1">
                      * One Transaction ID/UTR can only be submitted once to prevent duplicates. Duplicate attempts are rejected automatically to prevent exploit verification.
                    </p>
                  </div>

                  <button
                    type="submit"
                    disabled={submitting}
                    className="w-full bg-rose-600 hover:bg-rose-500 text-white font-bold py-3.5 px-4 rounded-xl text-sm flex items-center justify-center gap-1.5 cursor-pointer transition-colors disabled:opacity-50"
                  >
                    <span>{submitting ? "Verifying uniqueness..." : "Complete Order"}</span>
                    <ShieldCheck size={14} />
                  </button>
                </form>
              </motion.div>
            )}

            {/* STEP 4: Success Message */}
            {step === 4 && (
              <motion.div
                key="step-4"
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                className="text-center space-y-5 py-4"
              >
                <div className="w-16 h-16 bg-emerald-100 rounded-full flex items-center justify-center mx-auto text-emerald-600 shadow-md">
                  <Check size={32} className="stroke-[3]" />
                </div>

                <div className="space-y-1.5">
                  <h4 className="text-lg font-extrabold text-slate-900 dark:text-slate-100">Order Placed Successfully!</h4>
                  <p className="text-xs text-rose-600 font-bold font-mono">TRACK ID: #{successOrderId}</p>
                </div>

                <p className="text-xs text-slate-500 leading-relaxed max-w-[320px] mx-auto bg-slate-50 dark:bg-slate-950 p-3.5 rounded-2xl border border-slate-100">
                  <strong>Verification ongoing.</strong> Deliver within 2 to 10 working minute on your registered email ID: <span className="font-semibold">{deliveryEmail}</span>.
                </p>

                <div className="flex justify-center gap-2 pt-2">
                  <button
                    onClick={() => {
                      if (successOrderId) onOrderPlaced(successOrderId);
                      onClose();
                    }}
                    className="bg-slate-900 dark:bg-slate-800 text-white px-6 py-3 rounded-xl text-xs font-bold hover:bg-slate-800 cursor-pointer"
                  >
                    Track order state
                  </button>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </motion.div>
    </div>
  );
}
