export interface Order {
  id: string;              // 10-digit random Order ID
  userEmailOrId: string;   // User's login identification (guest random id or real email)
  email: string;           // Target email for order codes
  playerId?: string | null;       // Target player ID for gaming orders
  brand: string;           // Gift card brand name
  faceValue: number;       // Original face value
  paidAmount: number;      // Paid amount (50% discount rate)
  utr: string;             // Submitted UTR/Transaction ID
  status: "Pending" | "Approved" | "Declined";
  couponCode?: string;     // The delivered code (visible after approval)
  createdAt: string;       // Placed timestamp (ISO String)
  deviceInfo?: string;     // Client device fingerprint at order time
  rewardType?: string;     // e.g. "UC" or "Diamonds"
  rewardAmount?: number;   // e.g. 380, 1080
}

export interface BrandProduct {
  id: string;
  name?: string;
  originalPrice: number;
  sellingPrice: number;
  discountPercentage: number;
  stock: number;
  rewardType?: string;   // e.g., "UC", "Diamonds", "Coins", "Gift Card"
  rewardAmount?: number; // e.g., 60, 100, 500
}

export interface Brand {
  id: string;
  name: string;
  category: "retail" | "gaming" | "entertainment" | "utility" | string;
  imageUrl: string;
  textColor: string;
  bgHex: string;
  popularDenominations: number[]; // legacy
  products?: BrandProduct[];
  rateText: string;        // e.g., "50% Flat OFF"
  requiresPlayerId?: boolean; // Required fields variant flag
  requiresEmail?: boolean; // Option to show/hide email requirement
}

export interface UsedUTR {
  utr: string;
  orderId: string;
  createdAt: string;
}

export interface UserProfile {
  id: string;              // 7-digit random Guest ID or unique email ID
  name: string;            // Guest random display name or parsed name
  isGuest: boolean;
  email?: string;
  pin?: string;            // 6-digit PIN for account recovery/login
  deviceInfo?: string;     // Client device tracking info
  createdAt?: string;      // Registration date
  isBlocked?: boolean;     // Admin block flag
}

export interface PromoBanner {
  id: string;
  imageUrl: string;
  title: string;
  subtitle: string;
  badge?: string;
  link?: string;
  createdAt: string;
}

