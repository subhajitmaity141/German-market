import { Brand } from "./types";

export const BRANDS: Brand[] = [
  {
    id: "amazon",
    name: "Amazon Pay Gift Card",
    category: "retail",
    imageUrl: "https://images.unsplash.com/photo-1523474253046-8cd2748b5fd2?w=150&auto=format&fit=crop&q=60&ixlib=rb-4.0.3",
    textColor: "text-amber-500",
    bgHex: "#FF9900",
    popularDenominations: [500, 1000, 2000, 5000],
    rateText: "Flat 50% OFF"
  },
  {
    id: "flipkart",
    name: "Flipkart Gift Card",
    category: "retail",
    imageUrl: "https://images.unsplash.com/photo-1607082348824-0a96f2a4b9da?w=150&auto=format&fit=crop&q=60&ixlib=rb-4.0.3",
    textColor: "text-blue-500",
    bgHex: "#2874F0",
    popularDenominations: [500, 1000, 2500, 5000],
    rateText: "Flat 50% OFF"
  },
  {
    id: "googleplay",
    name: "Google Play Gift Code",
    category: "gaming",
    imageUrl: "https://images.unsplash.com/photo-1550745165-9bc0b252726f?w=150&auto=format&fit=crop&q=60&ixlib=rb-4.0.3",
    textColor: "text-emerald-500",
    bgHex: "#34A853",
    popularDenominations: [500, 1000, 1500, 3000],
    rateText: "Flat 50% OFF"
  },
  {
    id: "pelican",
    name: "Pelican Gift Code",
    category: "entertainment",
    imageUrl: "https://images.unsplash.com/photo-1498050108023-c5249f4df085?w=150&auto=format&fit=crop&q=60&ixlib=rb-4.0.3",
    textColor: "text-purple-500",
    bgHex: "#8B5CF6",
    popularDenominations: [500, 1000, 2000, 4000],
    rateText: "Flat 50% OFF"
  },
  {
    id: "steam",
    name: "Steam Wallet Code",
    category: "gaming",
    imageUrl: "https://images.unsplash.com/photo-1511512578047-dfb367046420?w=150&auto=format&fit=crop&q=60&ixlib=rb-4.0.3",
    textColor: "text-slate-400",
    bgHex: "#171a21",
    popularDenominations: [600, 1200, 3000, 6000],
    rateText: "Flat 50% OFF"
  },
  {
    id: "netflix",
    name: "Netflix Gift Card",
    category: "entertainment",
    imageUrl: "https://images.unsplash.com/photo-1574375927938-d5a98e8edd86?w=150&auto=format&fit=crop&q=60&ixlib=rb-4.0.3",
    textColor: "text-red-500",
    bgHex: "#E50914",
    popularDenominations: [500, 1000, 2000, 3000, 5000],
    rateText: "Flat 50% OFF"
  },
  {
    id: "spotify",
    name: "Spotify Premium Gift",
    category: "entertainment",
    imageUrl: "https://images.unsplash.com/photo-1614680376593-902f74fa0d41?w=150&auto=format&fit=crop&q=60&ixlib=rb-4.0.3",
    textColor: "text-green-500",
    bgHex: "#1DB954",
    popularDenominations: [719, 1189],
    rateText: "Flat 50% OFF"
  },
  {
    id: "playstation",
    name: "PlayStation Store Card",
    category: "gaming",
    imageUrl: "https://images.unsplash.com/photo-1606144042614-b2417e99c4e3?w=150&auto=format&fit=crop&q=60&ixlib=rb-4.0.3",
    textColor: "text-blue-600",
    bgHex: "#003087",
    popularDenominations: [500, 1000, 2000, 2500, 4000, 5000],
    rateText: "Flat 50% OFF"
  },
  {
    id: "xbox",
    name: "Xbox Live Gift Code",
    category: "gaming",
    imageUrl: "https://images.unsplash.com/photo-1605901309584-818e25960a8f?w=150&auto=format&fit=crop&q=60&ixlib=rb-4.0.3",
    textColor: "text-green-600",
    bgHex: "#107C10",
    popularDenominations: [500, 1000, 2000, 3000, 5000],
    rateText: "Flat 50% OFF"
  },
  {
    id: "bgmi",
    name: "BGMI UC Code",
    category: "gaming",
    imageUrl: "https://images.unsplash.com/photo-1542751371-adc38448a05e?w=150&auto=format&fit=crop&q=60&ixlib=rb-4.0.3",
    textColor: "text-orange-500",
    bgHex: "#FF6F00",
    popularDenominations: [500, 750, 1500, 3800, 5000],
    rateText: "Flat 50% OFF",
    requiresPlayerId: true
  },
  {
    id: "freefire",
    name: "Free Fire Max Diamonds",
    category: "gaming",
    imageUrl: "https://images.unsplash.com/photo-1620288627223-53302f4e8c74?w=150&auto=format&fit=crop&q=60&ixlib=rb-4.0.3",
    textColor: "text-yellow-500",
    bgHex: "#FFD700",
    popularDenominations: [500, 800, 1600, 4000],
    rateText: "Flat 50% OFF",
    requiresPlayerId: true
  },
  {
    id: "valorant",
    name: "Valorant Points Code",
    category: "gaming",
    imageUrl: "https://images.unsplash.com/photo-1614027164847-1b28cfe1df60?w=150&auto=format&fit=crop&q=60&ixlib=rb-4.0.3",
    textColor: "text-rose-600",
    bgHex: "#FF4655",
    popularDenominations: [500, 800, 1600, 4000, 8000],
    rateText: "Flat 50% OFF",
    requiresPlayerId: true
  }
];
